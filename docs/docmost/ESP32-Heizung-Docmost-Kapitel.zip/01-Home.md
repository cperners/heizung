# ESP32-Heizungssteuerung

Dieses Wiki beschreibt die bestehende Heizungssteuerung und ihre Bedienung. Die Dokumentation ist mit dem aktuellen Quellstand abgeglichen. Die geregelte Restwärmefunktion ist lokal geprüft; der vollständige Gerätetest steht aus.

Die Firmware verbindet Heizungs- und Boilerregelung, Mischersteuerung, fünf Temperaturfühler, eine lokale LCD-Anzeige und eine Weboberfläche. MQTT dient zur Übertragung von Messwerten und zur Fernbedienung. Die Uhrzeit stammt aus dem Netzwerk; eine separate Hardware-RTC wird nicht benötigt.

## Inhalt

- [Anmeldung und Netzwerk](https://github.com/cperners/heizung/wiki/Anmeldung-und-Netzwerk): geschützte Einstellungen, Passwortänderung, WLAN, MQTT und offener Update-Zugang.
- [Bedienung](https://github.com/cperners/heizung/wiki/Bedienung): Weboberfläche, Regelungsarten, Betriebsarten und Einstellungen.
- [Geregelte Restwärmeabfuhr in Betriebsart Aus](https://github.com/cperners/heizung/wiki/Restwaermebetrieb): Geregelte Wärmeabfuhr in Aus, Zieltemperatur und Testablauf.
- [Urlaubsbetrieb](https://github.com/cperners/heizung/wiki/Urlaubsbetrieb): Durchgehende Raumtemperatur, Boiler aus und MQTT-Bedienung.
- [MQTT](https://github.com/cperners/heizung/wiki/MQTT): Themen, Nachrichtenformate, Befehle und JSON-Status.
- [Sensoren und Fehlerverhalten](https://github.com/cperners/heizung/wiki/Sensoren-und-Fehlerverhalten): Fühler, Validierung und Reaktion der Ausgänge.
- [Installation und Updates](https://github.com/cperners/heizung/wiki/Installation-und-Updates): Konfiguration, Build, OTA und lokales HTTPS.
- [Architektur](https://github.com/cperners/heizung/wiki/Architektur): Quellcodeaufteilung, Datenübergaben und Bibliotheken.
- [Tests und Fehlersuche](https://github.com/cperners/heizung/wiki/Tests-und-Fehlersuche): Prüfabläufe und bekannte Grenzen.

## Funktionsübersicht

| Bereich | Funktion |
|---|---|
| Messwerte | Küche/Raum, Außen, Kessel, Vorlauf, Boiler und externe Kachelofentemperatur |
| Regelung | Manuell nach Raumtemperatur, manuell nach Außentemperatur oder automatisch nach Kachelofenstatus |
| Betriebsart | Aus, Automatikbetrieb, nur Heizung, nur Boiler oder Urlaub |
| Bedienung | Weboberfläche und lokale LCD-/Tastaturbedienung |
| Zeitprogramm | Tag- und Nachtbeginn mit getrennten Wunschraumtemperaturen |
| Netzwerk | WLAN, MQTT, Netzwerkzeit und OTA-Updates |
| Diagnose | Sensorfehler, Ausgangsstatus, Laufzeit, CPU-Schätzung, Speicher-/Schleifendiagnose und NTP-Abweichungen |

## Einordnung

Das Projekt ist eine individuell angepasste Steuerung. Die eingebauten Fehlerreaktionen ersetzen keine unabhängigen Temperaturbegrenzer oder eine vollständige Prüfung der Anlage. Insbesondere die Mischer-Auffahrt bei Vorlaufsensorfehler ist eine bewusst gewählte, anlagenspezifische Funktion.

Funktionstests wurden am Testgerät und am aktiven Gerät durchgeführt. Eine vollständige Prüfung aller Fehlerkombinationen und ein dokumentierter Langzeittest stehen weiterhin aus. Einzelne Ausgänge werden als geschalteter Zustand angezeigt; eine Rückmeldung der realen Pumpenbewegung oder Brennerfunktion ist nicht vorhanden.

## Neueste Ergänzungen

Die Temperatur-Kacheln enthalten die zugehörigen Ausgangssymbole. Boiler-Solltemperatur, Einschaltdifferenz, Vorlaufmaximum und Kurvensteilheit sind auf der Webseite einstellbar. Nur Boiler begrenzt die erste Mischer-Schließfahrt auf zwei Minuten und prüft nach zehn Minuten einmalig auf fehlende Vorlauf-Abkühlung. Bedienung und noch offene Gerätetests stehen auf [Bedienung](https://github.com/cperners/heizung/wiki/Bedienung) und [Tests und Fehlersuche](https://github.com/cperners/heizung/wiki/Tests-und-Fehlersuche).

## Aktueller Funktionsstand

Neu ist die geregelte Restwärmeabfuhr in Aus mit Brennersperre und gespeicherter Zieltemperatur von 30 bis 40 °C (Standard 35 °C). Hinzu kommen die getrennte 30-Grad-Heizkreisfreigabe bei Außentemperaturregelung, 21 Minuten Gültigkeit für Kachelofenmeldungen sowie die WLAN-/Neustartdiagnose. Die neue Restwärmefunktion ist lokal gebaut und geprüft, der vollständige Gerätetest steht aus. Siehe [Geregelte Restwärmeabfuhr in Betriebsart Aus](https://github.com/cperners/heizung/wiki/Restwaermebetrieb).

Die Raumregelung prüft nun auch bei fehlender Kesselfreigabe, ob ein gültiger Raumwert den Sollwert erreicht hat. Dies kann eine laufende Pumpenanforderung beenden, ohne eine zusätzliche Abschaltung allein wegen niedriger Kesseltemperatur einzuführen. Ein neuer Start benötigt weiterhin die bisherige Kesselfreigabe. Der Parallelbetrieb bleibt erhalten; Details auf [Bedienung](https://github.com/cperners/heizung/wiki/Bedienung).

## Raumwärmebedarf mit geregeltem Vorlauf

In Automatik und Nur Heizung bestimmt bei Raumregelung die Raumtemperatur weiterhin den Bedarf. Während die Pumpe läuft, regelt der Mischer den Vorlauf nach Heizkurve. Ein gültiger Außenfühler ist nun auch für diese Kombination erforderlich. Neue Pumpenstarts bleiben an die bisherige Kesselfreigabe gebunden. Der Parallelbetrieb mit dem Boiler bleibt erhalten.

Normale Mischerimpulse haben jetzt eine unabhängige Zeitfrist und eine Ruhezone von ±0,5 °C. Die Vorlauf-Kachel zeigt Sollwert und Ist-Soll-Differenz. Die normale Boilerladung wird bei Kesseltemperatur höchstens Boilertemperatur auch dann unterbrochen, wenn die übrige Ladeprüfung übersprungen wird. Die lokalen Tests und der Build waren erfolgreich; der vollständige Gerätetest dieser Ergänzungen ist offen.

## Anmeldung und Netzwerk auf der Webseite

Alle Werte bleiben sichtbar; Regelung und Betriebsart frei bedienbar. Die übrigen
Web-Einstellungen benötigen eine Anmeldung. Gespeicherte Anmeldepasswörter können
bis 64 UTF-8-Bytes lang sein. WLAN sowie MQTT-Server, Port, Basispfad und optionale
Broker-Zugangsdaten lassen sich nach Anmeldung testen und speichern. Bei Fehlern
wird die bisherige Konfiguration wieder verwendet. Die Update-Seite und der Upload
bleiben auf ausdrücklichen Wunsch ohne Anmeldung erreichbar.

Die Passwortänderung und der offene Update-Zugang sind am Gerät bestätigt. Weitere
Netzwerk- und Passwortgrenzfälle sind lokal geprüft, aber noch nicht vollständig am
Gerät dokumentiert. Details: [Anmeldung und Netzwerk](https://github.com/cperners/heizung/wiki/Anmeldung-und-Netzwerk).

## Markdown für Docmost

Die vollständige Projektdokumentation steht zusätzlich als zusammenhängende Markdown-Datei
und als ZIP mit zwölf einzelnen Markdown-Kapiteln bereit. Eine Import-Anleitung liegt bei.
Siehe [Docmost-Import](https://github.com/cperners/heizung/wiki/Docmost-Import).

## Schaltanalyse und grafische Heizkurve

Neu sind [MQTT-Protokoll der Schaltausgaenge](https://github.com/cperners/heizung/wiki/MQTT-Schaltereignisse) mit Node-RED-Auswertung und eine eigene
breite Kachel [Dynamische Heizkurvengrafik](https://github.com/cperners/heizung/wiki/Heizkurve). Die Vorschau bei Aus ist korrigiert.
Build und lokale Pruefungen sind erfolgreich; die neuesten Darstellungs- und
Ereignis-Geraetetests bleiben als offen dokumentiert.

## Anmeldung bei Bedarf

Seit dem 2. November 2026 erscheinen Benutzername und Passwort erst nach Klick
auf **Anmelden**. Die bisherigen Zugriffsregeln bleiben erhalten.
Siehe [Anmeldung und Netzwerk](https://github.com/cperners/heizung/wiki/Anmeldung-und-Netzwerk). Die lokale Pruefung ist erfolgreich,
der Geraetetest der neuen Bedienfolge bleibt offen.
