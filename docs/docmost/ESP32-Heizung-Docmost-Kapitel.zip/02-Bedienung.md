# Bedienung

## Weboberfläche

Messwerte und Sollwerte bleiben ohne Anmeldung sichtbar. **Regelung** und **Betriebsart**
bleiben frei bedienbar; die übrigen Web-Einstellungen lassen sich erst nach Anmeldung
ändern und speichern. Passwortänderung, WLAN und MQTT stehen im geschützten Bereich.
Die Update-Seite ist ausdrücklich ausgenommen. Details: [Anmeldung und Netzwerk](https://github.com/cperners/heizung/wiki/Anmeldung-und-Netzwerk).

Die Kopfzeile zeigt Gerätename, Laufzeit seit Neustart, eine grobe CPU-Schätzung für beide Kerne sowie Datum und Uhrzeit. Auf schmalen Displays darf die Kopfzeile umbrechen. Laufzeit und CPU-Schätzung sind hellgelb dargestellt.

Die erste Kartenreihe enthält die fünf direkt angeschlossenen Temperaturfühler. Weitere Karten zeigen Gasverbrauch, Regelungsart, Betriebsart und NTP-Server. Die separate Ausgangsstatus-Kachel ist entfallen. Wunschraumtemperaturen und Kachelofenfunktionen stehen gemeinsam in einer weiteren Reihe.

Die Webseite fragt einmal pro Sekunde einen gemeinsamen Status ab. Der ESP32 stellt diesen in seiner Hauptschleife zusammen. Bei einem veralteten oder nicht erreichbaren Status erscheinen die Ausgangssymbole grau und erhalten einen Hinweis auf den fehlenden Status.

### Temperaturtrend

Neben den Temperaturen einschließlich Kachelofen steht ein Trendpfeil:

| Zeichen | Bedeutung |
|---|---|
| ↑ orange | Gegenüber der vorherigen gültigen Messung mindestens etwa 0,1 °C gestiegen |
| ↓ blau | Gegenüber der vorherigen gültigen Messung mindestens etwa 0,1 °C gesunken |
| ↔ | Änderung kleiner als 0,1 °C oder erste gültige Messung |
| Kein Pfeil | Kein gültiger aktueller Messwert oder Verbindung ausgefallen |

Der Trend vergleicht aufeinanderfolgende Messungen, keine Stundenmittelwerte. Wiederholte Webabfragen desselben Messwerts verändern den Pfeil nicht. Nach einem erkannten Sensorfehler beginnt der Vergleich neu.

## Regelungsart und Betriebsart

Diese beiden Einstellungen haben unterschiedliche Aufgaben.

**Regelungsart** bestimmt, welche Temperatur für die Raumheizung maßgeblich ist:

- **Manuell Raumtemperatur:** Die Raumtemperatur bestimmt den Heizbedarf, unabhängig vom Kachelofenstatus. In Automatikbetrieb und Nur Heizung regelt der Mischer während laufender Pumpe den Vorlauf nach Heizkurve. Ein gültiger Außenfühler ist dafür ebenfalls erforderlich.
- **Manuell Außentemperatur:** Außenregelung bleibt ausgewählt, unabhängig vom Kachelofenstatus.
- **Automatik:** Bei aktivem Kachelofen wird die Außenregelung verwendet; bei inaktivem Kachelofen die Raumregelung.

**Betriebsart** wählt den Betriebsumfang: Aus, Automatikbetrieb, nur Heizung, nur Boiler oder Urlaub. Die Auswahl wird jeweils mit **Übernehmen** bestätigt. Sensorsperren werden durch diese Auswahl nicht aufgehoben.

## Wunschtemperaturen und Zeitprogramm

Tag- und Nacht-Wunschtemperaturen lassen sich in Schritten von 0,1 °C ändern. Die Webeingabe akzeptiert 5 bis 40 °C. Im selben Formular stehen die gespeicherten Tag- und Nachtbeginnzeiten als Uhrzeitfelder.

Mit **Temperaturen und Zeiten speichern** wird eine Anfrage an die Hauptschleife übergeben. Erst nach erfolgreicher Speicherung erscheint die Bestätigung. Bei einem Speicherfehler bleiben die bisherigen Wunschtemperaturen und Zeiten aktiv.

Der Tagbeginn muss vor dem Nachtbeginn liegen. Ein Tagesintervall über Mitternacht unterstützt dieses Formular nicht. Die bestehende Zeitlogik verwendet strenge Grenzen: Tagbetrieb gilt nach dem Tagbeginn und vor dem Nachtbeginn; exakt an der eingestellten Beginnminute gilt noch Nachtbetrieb. Das ist eine erhaltene Eigenschaft der Bestandslogik.

## Kachelofen

Die externe Temperatur kommt per MQTT. Die Schaltschwellen haben eine Hysterese: Aktivierung ab Einschaltgrenze, Deaktivierung bei oder unter Ausschaltgrenze. Die Einschaltgrenze muss größer als die Ausschaltgrenze sein. Die Tasten ändern die Werte in halben Gradschritten.

Bleibt länger als 21 Minuten eine gültige Temperaturmeldung aus, gilt der Kachelofen als inaktiv. In Automatik führt das zur Raumregelung. Eine manuell gewählte Regelungsart bleibt bestehen.

## Temperatur-Kacheln und Ausgangssymbole

Küche, Außen, Gaskessel, Vorlauf und Boiler zeigen oben die Bezeichnung, darunter Thermometersymbol, Messwert und Einheit. Danach folgen die zugehörigen Ausgangssymbole und anschließend Hinweise und Einstellungen.

| Kachel | Symbol und Bedeutung |
|---|---|
| Gaskessel | Flamme: Pastellrot bei Brennerausgang ein, Grau bei aus; Heizungspumpe: Grün bei Ausgang ein, Grau bei aus |
| Boiler | Boilerpumpe: Grün bei Ausgang ein, Grau bei aus |
| Vorlauf | Dreiwegeventil: Grün bei Fahrt mit ↑ Auf oder ↓ Zu, Grau bei Stopp |

Alle Symbole zeigen die geschalteten Ausgänge, keine mechanische Rückmeldung und keine bestätigte Flammenerkennung. Fehlende Webdaten werden grau mit entsprechendem Statushinweis angezeigt. Gleichzeitig aktive Mischer-Richtungen werden als Ausgangskonflikt angezeigt.

Das LCD zeigt ungültige Sensorwerte als X und aktualisiert nur geänderte Zeichen. Die Rückkehr aus einem Menü muss am Gerät vollständig geprüft werden.

## Boiler-Solltemperatur und Einschaltdifferenz

In der Boiler-Kachel lassen sich Solltemperatur und Einschaltdifferenz mit − / + in 0,1-°C-Schritten einstellen. Beide Felder sind mit den gespeicherten Werten vorbelegt. Der bestehende zulässige Wertebereich beträgt jeweils 0 bis 100 °C; er ist keine Empfehlung für die Anlage.

**Boilereinstellungen speichern** übergibt beide Werte an die Hauptschleife. Erst nach erfolgreichem EEPROM-Commit werden sie aktiv und als gespeichert bestätigt. Bei Fehler bleiben die bisherigen Werte aktiv. Unveränderte Werte lösen keinen erneuten Schreibvorgang aus. LCD und Webseite verwenden dieselben Speicherstellen.

Eine neue Ladung beginnt unter Solltemperatur minus Einschaltdifferenz; eine laufende Ladung endet bei Erreichen der Solltemperatur. Die Boiler-Kachel zeigt dazu den aktuellen Sollwert, die Einschaltdifferenz und die berechnete Startgrenze.

Zusätzlich erscheint **Differenz Kessel − Boiler** mit Vorzeichen und zwei Nachkommastellen: positive Werte in Pastellrot, null oder negative Werte in Pastellblau. Bei ungültigem Kessel- oder Boilersensor steht ein Fehlerhinweis. Dies ist ausschließlich eine Anzeige; die bisherige Pumpenfreigabe bei wärmerem Kessel bleibt unverändert.

## Heizkurve auf der Webseite

In der Vorlauf-Kachel stehen Messwert, berechneter Vorlauf-Sollwert und die Differenz Ist minus Soll. Die Differenz ist bei wärmerem Vorlauf positiv und bei kälterem negativ. Unter dem Mischersymbol stehen die Einstellungen für Vorlaufmaximum, Kurvensteilheit und Restwärmeziel. Beide lassen sich in 0,1-Schritten ändern und gemeinsam mit **Vorlaufeinstellungen speichern** sichern. Vorlaufmaximum: 0 bis 100 °C; Kurvensteilheit: 0,1 bis 10, ohne Einheit.

Die Werte entsprechen den vorhandenen LCD-Einstellungen und wirken bei Außentemperaturregelung. Die bestehende Heizkurvenprüfung bleibt aktiv: Beispielsweise führt ein Vorlaufmaximum unter der gewünschten Raumtemperatur zu einer ungültigen Heizkurve und keiner daraus abgeleiteten Heizanforderung. Bei Speicherfehlern bleiben beide bisherigen Einstellungen aktiv.

## Mischer in Nur Boiler

Beim Wechsel zu **Nur Boiler** und beim Start in dieser Betriebsart wird einmalig für zwei Minuten Mischer zu geschaltet. Danach sind beide Richtungen aus; die Fahrt startet innerhalb derselben Betriebsart nicht erneut. Beim Verlassen wird sie abgebrochen. Die normale Mischerinitialisierung wird währenddessen unterdrückt.

Die Dauer steht separat in `config.h` als `MISCHER_BOILER_ZUFAHRT_MINUTEN` mit Standardwert `2UL`. Die Restwärme-Wartebedingung von Aus gilt hier nicht. Die bestehende Vorlaufsensor-Fehlerreaktion hat Vorrang; die Zwei-Minuten-Frist wird ab Eintritt in Nur Boiler gemessen und bei einer Sensorsperre nicht neu gestartet.

Zehn Minuten nach Ende der ersten Schließfahrt wird der aktuelle Vorlauf mit dem Messwert beim Fahrtende verglichen. Ist die Temperatur gesunken, bleibt der Mischer stehen. Bei gleicher oder höherer Temperatur folgt genau eine weitere Schließfahrt mit derselben Dauer von zwei Minuten; anschließend bleibt der Mischer stehen. Es gibt keine endlose Wiederholung. Jede messbare Abnahme zählt, ohne zusätzliche Temperaturschwelle.

Die Wartezeit steht in `config.h` als `MISCHER_BOILER_NACHPRUEFUNG_MINUTEN` mit Standardwert `10UL`. Bei ungültigem Vergleichswert wird keine Nachfahrt ausgelöst. Ein Vorlaufsensorfehler während der Wartephase verwirft die Referenz; die bestehende Sensorfehlerbehandlung bleibt vorrangig. Verlassen von Nur Boiler bricht den gesamten Ablauf ab. Ein erneuter Eintritt beginnt einen neuen Ablauf.

## Geregelte Restwärme in Aus

Beim Wechsel von Automatik oder Nur Heizung auf **Aus** wird der Brenner abgeschaltet und über die zentrale Ausgangsfunktion gesperrt. Neue Heiz- und Boileranforderungen sind aus. Bei warmem Kessel führt der Heizkreis Restwärme ab: Die Heizungspumpe läuft und der Mischer regelt den Vorlauf nach der vorhandenen Heizkurve. Dies gilt auch bei zuvor gewählter Raumtemperaturregelung; die erreichte Raumtemperatur verhindert diese Restwärmeabfuhr nicht.

Die Zieltemperatur ist in der **Vorlauf-Kachel** in 0,1-°C-Schritten von **30 bis 40 °C** einstellbar. Der Standard bleibt **35 °C**. Mit **Vorlaufeinstellungen speichern** werden Zieltemperatur, Vorlaufmaximum und Kurvensteilheit gemeinsam gespeichert und erst nach erfolgreichem Speichern aktiv. Der Wert bleibt nach Neustart erhalten.

Bei gültiger Kesseltemperatur höchstens Zieltemperatur endet die reguläre Pumpenanforderung. Der Mischer fährt einmalig für die eingestellte Dauer (Standard zwei Minuten) zu und stoppt dann. Erwärmt sich der Kessel erneut über das Ziel, wird die Schließfahrt abgebrochen und die geregelte Restwärmeabfuhr wieder aufgenommen. Das gilt auch beim Start mit gespeicherter Betriebsart Aus.

Die Webseite zeigt **AUS / RESTWAERME** und **RESTWAERME / HEIZKURVE**. Die Heizkurve nutzt Tag-/Nacht-Sollwert und Außentemperatur; ihr Vorlauf-Sollwert bleibt durch das vorhandene Vorlaufmaximum begrenzt. Sensorfehlersperren, begrenzter Fehlernachlauf und die separate Pumpenschutzbewegung bleiben bestehen. Die hydraulische Wärmeabfuhr und der reale Ablauf müssen am Gerät noch geprüft werden. Details: [Geregelte Restwärmeabfuhr in Betriebsart Aus](https://github.com/cperners/heizung/wiki/Restwaermebetrieb).

## Heizkreisfreigabe bei Außentemperaturregelung

In Automatik und Nur Heizung wird der Heizkreis bei Außentemperaturregelung unabhängig von der bisherigen Boiler-Kesselfreigabe behandelt. Bei gültigen Sensoren und gültiger Heizkurve ist die Freigabe ab 30 °C Kesseltemperatur möglich. Darunter werden die reguläre Pumpenanforderung beendet und normale Mischerbewegungen gestoppt; die gesonderte Initialisierung und Sensorfehlerbehandlung bleiben bestehen. Die Boilerfreigabe bleibt unverändert. In der Raumregelung gilt die unten beschriebene Trennung zwischen neuem Pumpenstart und Abschalten am Raum-Sollwert.

Diese 30-Grad-Heizkreisgrenze und die einstellbare Restwärme-Zieltemperatur von standardmäßig 35 °C sind unterschiedliche Parameter. Die erste gilt im Heizbetrieb, die zweite für die Wärmeabfuhr in Aus.

## Systemdiagnose

Eine eigene Karte zeigt freien Arbeitsspeicher, dessen bisheriges Minimum, den größten freien Speicherblock sowie Schleifenabstände. Ein Abstand umfasst alles zwischen zwei Schleifenstarts einschließlich Wartezeiten und ist keine reine CPU-Ausführungszeit. Historische Maxima und Zähler gelten seit Neustart.

Zur Fehlersuche Werte kurz nach dem Start und beim Auftreten einer Verzögerung vergleichen. Eine einzelne Momentaufnahme beweist oder widerlegt kein Speicherleck.

## LoRaWAN-Kachelofentemperatur

Die Quelle liefert alle fünf Minuten. Der Timeout von 21 Minuten überbrückt bei regelmäßiger Fünf-Minuten-Sendung drei ausbleibende Meldungen mit etwas Zeitreserve. Danach wird der Ofen als inaktiv behandelt. Die Temperaturmeldung ist eine reine Zahl mit Dezimalpunkt. Beim geprüften Node-RED/ioBroker-Ausgang musste der Schreibtyp auf `command` (`ack=false`) stehen, damit der MQTT-Adapter sie tatsächlich veröffentlichte. Das hängt von der Adapterkonfiguration ab; ein aktualisierter ioBroker-Datenpunkt allein bestätigt keinen MQTT-Versand.

## Urlaub und WLAN-Kachel

Urlaub hält eine eigene einstellbare Raumtemperatur durchgehend, ohne Boilerbereitung. Die Bedienung, MQTT-Befehle und Grenzen stehen auf [Urlaubsbetrieb](https://github.com/cperners/heizung/wiki/Urlaubsbetrieb). Die normale Tag-/Nachttemperatur bleibt separat erhalten.

WLAN-Netzwerkname und Signalstärke stehen jetzt in einer gemeinsamen Kachel und werden mit dem Webstatus aktualisiert. Der unbeschriftete WLAN-Schieberegler wurde entfernt.

## OTA-Status

In der Systemdiagnose zeigt die Zeile OTA den zuletzt beobachteten Update-Zustand seit Neustart. Weitere Angaben liefert der lesende Geräte-Endpunkt `/ota-status`. Die Diagnose ist erst nach Installation der optimierten Firmware verfügbar und wird beim Neustart zurückgesetzt.

## Kombinierte Raum- und Heizkurvenregelung

In **Automatikbetrieb** und **Nur Heizung** entscheidet bei Raumregelung weiterhin die Raumtemperatur über den Heizbedarf. Der aktuelle Tag-/Nacht-Sollwert und die bisherige Raum-Einschaltdifferenz bleiben erhalten. Während die Heizungspumpe läuft, regelt der Mischer den Vorlauf nach derselben Heizkurve wie bei Außenregelung, begrenzt durch das Vorlaufmaximum.

Ein neuer Pumpenstart benötigt weiterhin die bisherige Kesselfreigabe. Eine laufende Pumpe wird nicht allein wegen Unterschreiten dieser Kesselfreigabe abgeschaltet: Bei weiterem Raumwärmebedarf bleiben Pumpenanforderung und Vorlaufregelung wirksam. Erreicht der Raum seinen Sollwert, endet die reguläre Pumpenanforderung und eine normale Mischerfahrt stoppt. Im Raum-Hystereseband bleibt der vorherige Pumpenzustand erhalten.

Für diese Kombination müssen **Kessel, Vorlauf, Außen und Raum** gültig gemessen werden. Bei einem zugeordneten Sensorfehler bleiben die bestehenden Fehlersperren und der begrenzte Nachlauf bereits laufender Pumpen aktiv. Ungültige Heizkurvenparameter erzeugen keine normale Pumpen- oder Mischeranforderung. Die gesonderte Mischerinitialisierung wird dadurch nicht zur normalen Heizkurvenfahrt.

Der **Urlaubsbetrieb behält seinen bisherigen Sonderablauf**. Bei Aus bleibt die gesonderte Restwärmeregelung maßgeblich. Boiler und Heizkreis können weiterhin parallel arbeiten; es wurde kein Boilervorrang eingeführt.

## Normale Mischerimpulse und Ruhezone

Bei normaler Heizkurvenregelung gilt eine Ruhezone von standardmäßig **±0,5 °C** um den Vorlauf-Sollwert. Innerhalb einschließlich beider Grenzen bleiben beide normalen Stellrichtungen aus. Eine laufende normale Fahrt wird beim Eintritt in die Ruhezone oder einem erkannten Richtungswechsel beendet. Die Ruhezone ist in `config.h` über `MISCHER_RUHEZONE_GRAD` einstellbar.

Ein normaler Impuls dauert höchstens fünf Sekunden. Die Hauptschleife prüft seine eigene Millisekundenfrist unabhängig vom Aufruf des Reglers und vom LCD-Zähler. Ist kein geregelter Heizkreis mehr aktiv, wird der normale Impuls ebenfalls gestoppt. Der vorhandene Abstand von 30 Sekunden zwischen normalen Impulsstarts bleibt bestehen.

Initialisierung, Nur-Boiler-Schließfahrt, deren einmalige Nachfahrt, abschließende Aus-Schließfahrt und Sensorfehler-Auffahrt behalten ihre eigenen Abläufe und Zeitgrenzen. Ein direkter Sonderfahrtbefehl übernimmt die Ausgänge und löscht die Zuordnung zu einem alten normalen Impuls. Die Softwarefrist ist keine unabhängige Hardwareabschaltung bei vollständig blockierter Hauptschleife.

## Boilerpumpe bei fehlender Temperaturdifferenz

Die normale Ladepumpenanforderung wird nun bei jeder zentralen Ausgangsaktualisierung zurückgesetzt, wenn gültige Temperaturen zeigen, dass der Kessel **nicht wärmer als der Boiler** ist. Dies wirkt auch dann, wenn die übrige Boilerprüfung wegen fehlender Kesselfreigabe übersprungen wird. Damit bleibt ein alter Ladepumpenzustand in diesem Fall nicht unverändert eingeschaltet.

Der vorhandene Sensorfehlernachlauf und die separate Pumpenschutzbewegung bleiben ausdrücklich bestehen. Eine tatsächliche Pumpenbewegung ist weiterhin nicht rückgemeldet; die Websymbole zeigen den geschalteten Ausgang.
