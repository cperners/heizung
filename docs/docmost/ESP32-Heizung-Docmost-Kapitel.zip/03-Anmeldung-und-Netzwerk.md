# Anmeldung und Netzwerk

## Anmeldefelder aufklappen

Beim Oeffnen der Heizungswebseite sind weiterhin alle Mess- und Einstellwerte
sichtbar. Im Anmeldebereich wird zunaechst nur die Schaltflaeche **Anmelden**
angezeigt. Benutzername und Passwort sind ausgeblendet.

1. **Anmelden** anklicken. Die beiden Eingabefelder erscheinen; der Fokus steht
   im Benutzernamenfeld.
2. Benutzername und Passwort eingeben und im Formular **Anmelden** anklicken.
3. Bei erfolgreicher Anmeldung verschwinden die Felder. Die geschuetzten
   Einstellungen werden freigegeben und **Abmelden** wird angezeigt.
4. **Abbrechen** schliesst das Formular ohne Anmeldung, leert das Passwortfeld
   und zeigt wieder die einzelne Anmelden-Schaltflaeche.
5. Nach Abmeldung oder Ablauf der Sitzung sind die Felder wieder ausgeblendet.

Waehrend der Eingabe bleibt das geoeffnete Formular trotz regelmaessiger
Sitzungspruefung geoeffnet. Bei fehlerhaften Zugangsdaten bleibt es fuer eine
Korrektur offen. Der Browser kann seine normale Passwortverwaltung verwenden;
die Firmware liefert kein gespeichertes Passwort an die Webseite zurueck.


Die neue Darstellung ist lokal geprueft und gebaut; der Geraetetest ist noch offen.

## Frei sichtbar und frei bedienbar

Alle Messwerte, Sollwerte und Diagnosen bleiben ohne Anmeldung sichtbar. Die beiden
Umschalter **Regelung** und **Betriebsart** bleiben jederzeit bedienbar. Alle übrigen
Web-Einstellungen erfordern eine Anmeldung: Wunschtemperaturen und Zeiten,
Boilerwerte, Vorlaufmaximum, Heizkurve, Restwärmeziel, Kachelofen-Schaltschwellen,
WLAN, MQTT und Änderung des Anmeldepassworts. MQTT-Befehle und LCD-Bedienung werden
von dieser Web-Anmeldung nicht verändert.

Die Eingabefelder starten gesperrt. Zusätzlich prüft der ESP jede geschützte
Speicheranfrage. Ein Umgehen der Oberflächensperre gibt damit keinen Speicherzugriff.
Der frühere direkte WebSocket-Pumpenschalter wird nicht mehr angeboten.

## Anmelden und abmelden

Die Anmeldung steht über den Kacheln. Benutzername und anfängliches Passwort werden
für jeden eigenen Build lokal in `src/secrets.h` über `HEIZUNG_WEB_USER` und
`HEIZUNG_WEB_PASSWORD` festgelegt. Produktive Zugangsdaten werden nicht veröffentlicht.
Ein auf dem Gerät gespeichertes Passwort hat beim nächsten Start Vorrang vor dem
Anfangswert der Firmware.

Eine Sitzung gilt für den jeweiligen Browser-Tab und bleibt beim Neuladen desselben
Tabs erhalten. Bis zu vier Sitzungen können bestehen; eine weitere Anmeldung ersetzt
die älteste. Nach 15 Minuten ohne geschützte Anfrage verfällt die Sitzung. Die reine
Hintergrundprüfung verlängert sie nicht. **Abmelden** oder ein ESP-Neustart beendet
sie. Anmeldeversuche sind auf einen Versuch je zwei Sekunden begrenzt.

## Anmeldepasswort ändern

Nach der Anmeldung das bisherige Passwort, das neue Passwort und seine Wiederholung
in der Kachel **Anmeldepasswort ändern** eingeben und speichern. Der Benutzername
bleibt unverändert. Erlaubt sind 1 bis **64 UTF-8-Bytes**; Umlaute und andere
Sonderzeichen können mehrere Bytes benötigen. Die frühere Acht-Zeichen-Grenze ist
aufgehoben. Bestehende achtstellige Passwörter bleiben beim Update gültig.

Erst nach erfolgreicher NVS-Speicherung gilt das neue Passwort. Ein falsches bisheriges
Passwort oder ein Speicherfehler lässt den bisherigen Wert aktiv. Bei Erfolg werden
alle Web-Sitzungen beendet; anschließend mit dem neuen Passwort anmelden. Das Passwort
bleibt bei Neustart und späteren Firmware-Updates erhalten.

## Ausnahme: Update-Seite

**Die Update-Seite und die Firmware-Upload-Endpunkte sind auf ausdrücklichen Wunsch
nicht passwortgeschützt.** Ein späterer Wechsel des Web-Anmeldepassworts aktiviert
dort keine Sperre. Wer den ESP im Netz erreicht, kann damit auch Firmware hochladen.
Die übrigen geschützten Einstellungen bleiben gesperrt.

Die frühere Ablehnung des geänderten Passworts an der separaten OTA-Anmeldung wurde
nicht abschließend erklärt. Der aktuelle Stand umgeht diese getrennte Anmeldung
bewusst; er ist keine nachgewiesene Behebung ihrer Ursache. Der offene Update-Zugang
wurde vom Betreiber am Gerät bestätigt.

Anmeldung und geschützte Einstellungen über den vorhandenen lokalen HTTPS-Proxy
nutzen. Der direkte ESP-Webserver bietet weiterhin HTTP; die Anmeldung verschlüsselt
die Verbindung nicht selbst. Details: [Installation und Updates](https://github.com/cperners/heizung/wiki/Installation-und-Updates).

## WLAN wechseln

1. Anmelden und in der WLAN-Kachel den neuen Netzwerkname und das neue WLAN-Passwort eingeben.
2. **WLAN testen und speichern** wählen. Die Annahmeantwort bestätigt noch keine Speicherung.
3. Der ESP wartet kurz auf die Antwortübertragung und testet das neue Netz ohne Warteschleife im Heizungsablauf.
4. Erst nach fünf Sekunden durchgehender Verbindung mit zugewiesener IP-Adresse werden die Daten als gemeinsamer NVS-Datensatz gespeichert.
5. Scheitert die Verbindung innerhalb von 30 Sekunden oder die Speicherung, versucht der ESP wieder das bisherige WLAN. Ein Stromausfall während des Tests lässt die zuvor gespeicherten Daten bestehen.

Der Name darf 1 bis 32 Bytes enthalten, die WPA/WPA2-Passphrase 8 bis 63 Bytes. Offene
WLANs und rohe 64-stellige PSK-Schlüssel werden in diesem Formular nicht angeboten.
Gespeicherte WLAN-Passwörter werden nicht an den Browser zurückgesendet. Ohne
gespeicherten Datensatz gelten die lokalen Firmware-Vorgaben.

In einem anderen WLAN kann sich die ESP-Adresse ändern. Dann gegebenenfalls
DHCP-Reservierung, DNS und das Weiterleitungsziel des HTTPS-Proxys anpassen. Eine
WLAN-Verbindung allein bestätigt noch keine Erreichbarkeit von Proxy oder MQTT.
Für den Rückfall muss das bisherige WLAN erreichbar sein. Es wird kein offener
Einrichtungshotspot gestartet.

## MQTT konfigurieren

In der geschützten MQTT-Kachel stehen:

| Feld | Bedeutung |
|---|---|
| Server | IPv4-Adresse oder Hostname ohne `http://` oder `mqtt://`, maximal 63 ASCII-Zeichen |
| Port | Ganze Zahl von 1 bis 65535 |
| Gemeinsamer Basispfad | Bis 80 ASCII-Zeichen ohne Leerzeichen, `+` oder `#`; abschließender Schrägstrich wird ergänzt |
| Benutzername | Optional, maximal 63 UTF-8-Bytes |
| Passwort | Optional, maximal 127 UTF-8-Bytes; wird nicht zurückgesendet |
| Gespeichertes Passwort beibehalten | Bei leerem Passwortfeld bisherigen Wert weiterverwenden |

**Benutzername und Passwort beide leer** bedeutet Verbindung ohne Broker-Anmeldung,
auch wenn die Auswahl zum Beibehalten noch gesetzt war. Ein Passwort ohne Benutzername
wird abgelehnt. Bei vorhandenem Benutzer ersetzt ein eingegebenes neues Passwort den
bisherigen Wert. Ohne Beibehalten-Auswahl kann auch ein leeres Passwort gespeichert
werden. Das Limit des Web-Anmeldepassworts gilt nicht für MQTT.

Server, Port, Basispfad und Zugangsdaten werden gemeinsam getestet und gespeichert.
Die Hauptschleife trennt den bisherigen Broker, leert alte Ein-/Ausgangswarteschlangen
und baut eine saubere MQTT-Sitzung auf. Während des Tests werden keine MQTT-Befehle
übernommen und keine Statuswerte veröffentlicht. Erst nach erfolgreicher
Broker-Verbindung wird gespeichert und werden die drei Themen für Steuerbefehle,
Kachelofen und Gaszähler abonniert. Scheitert der Verbindungsversuch innerhalb von
30 Sekunden oder die Speicherung, werden die bisherigen Werte gemeinsam wieder
verwendet. Eine erfolgreiche Verbindung bestätigt nicht sämtliche Broker-ACLs.

Alle Sende- und Empfangsthemen verwenden den neuen Basispfad. Ein führender Schrägstrich
wird beibehalten, aber nicht automatisch hinzugefügt. Node-RED, ioBroker und andere
Teilnehmer müssen ihre Themen ebenfalls umstellen. Historische Retain-Nachrichten
auf dem alten Broker oder Pfad werden nicht gelöscht. Sensor- und Brennersperrstatus
werden im neuen Pfad erneut veröffentlicht. Für den Kachelofen muss nach erfolgreicher
Umstellung eine neue Nachricht eintreffen; der bisherige Wert gilt nicht als frische
Messung aus dem neuen Thema.

Die alten gespeicherten Server-/Themen-Datensätze bleiben lesbar und übernehmen beim
Update zunächst die lokalen Broker-Zugangsdaten. Ein neuer gespeicherter Datensatz
enthält auch Benutzername und Passwort. WLAN und MQTT können nicht gleichzeitig
umgestellt werden. Ein MQTT-Wechsel ändert die ESP-IP-Adresse nicht.

## Prüfstand

Am Gerät bestätigt sind die Änderung des Anmeldepassworts und der anschließend
bewusst offene Update-Zugang. Die lokale Prüfung umfasst zusätzlich die längere
Passwortgrenze, Weiterverwendung alter Passwortdatensätze, Abmeldung, gesperrte
Speicheraufrufe, optionale MQTT-Anmeldung, Migration und Rückfall bei Netzwerk- oder
Speicherfehlern. WLAN-/MQTT-Wechsel und sämtliche Grenzfälle mit langen Passwörtern
sind noch nicht vollständig am Gerät dokumentiert. Siehe [Tests und Fehlersuche](https://github.com/cperners/heizung/wiki/Tests-und-Fehlersuche).
