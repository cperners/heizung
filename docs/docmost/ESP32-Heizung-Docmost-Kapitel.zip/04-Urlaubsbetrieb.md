# Urlaubsbetrieb

Urlaub ist eine eigene Betriebsart für eine durchgehende, einstellbare Raumtemperatur ohne Boilerbereitung. Der Betrieb bleibt aktiv, bis eine andere Betriebsart gewählt wird. Es gibt keine automatische Rückkehr nach einem Datum.

## Webbedienung

Die Betriebsarten stehen in der Reihenfolge **Aus, Automatikbetrieb, Nur Heizung, Nur Boiler, Urlaub**. Urlaub wählen und Übernehmen drücken. Unter Wunschraumtemperatur besitzt Urlaub eigene Plus-/Minus-Tasten in 0,1-Grad-Schritten. Anfangswert sind 15 °C, zulässig sind 5 bis 40 °C. Mit Temperaturen und Zeiten speichern wird die Einstellung übernommen; die Speicherbestätigung erscheint erst nach erfolgreichem Speichern.

Die Urlaubstemperatur gilt unabhängig vom Tag-/Nachtzeitprogramm. Die wirksame Regelung ist während Urlaub Raumregelung, unabhängig von der normalen Regelungsmodus-Auswahl und dem Kachelofenstatus. Die normale Auswahl bleibt erhalten und wird nach Verlassen von Urlaub wieder maßgeblich.

## Boiler, Sensoren und Mischer

Es entsteht keine Boiler-Heizanforderung. Eine bereits laufende Boilerpumpe kann bei einem zugeordneten Sensorfehler aufgrund des bestehenden Fehlernachlaufs vorübergehend weiterlaufen. Der Urlaubsmodus setzt die bestehenden Brenner-, Sensor- und Mischersperren nicht außer Kraft.

Urlaub ist nicht die Betriebsart Aus. Die temperaturabhängige zweiminütige Mischer-Schließfahrt von Aus wird beim Wechsel auf Urlaub beendet; die normale Mischerinitialisierung wird wieder freigegeben.

## MQTT

Alle Befehle auf dem bestehenden Steuer-Thema senden, im produktiven Aufbau `/SmartHome/Keller/Heizung/set`, als einfachen Text, QoS 1, Retain aus.

| Nachricht | Wirkung | Antwort im JSON-Feld answer |
|---|---|---|
| `seturlaub` | Urlaub aktivieren und speichern | `h_urlaub` |
| `urlaubTemp:16.5` | Urlaubstemperatur speichern; aktiviert Urlaub nicht selbst | `h_urlaubtemp` |
| `setwinter` | Urlaub beenden, Automatikbetrieb wählen | `h_winter` |
| `setheizung` | Urlaub beenden, nur Heizung wählen | `h_heizung` |
| `setboiler` | Urlaub beenden, nur Boiler wählen | `h_boiler` |
| `setoff` | Urlaub beenden, Aus wählen | `h_aus` |

Dezimalpunkt verwenden. Ungültige Temperatur ergibt `h_urlaubtemp_invalid`, fehlgeschlagene Speicherung `h_save_error`. Die Antworten erscheinen im regulären JSON-Status. Das ist weiterhin ein einzelner Antwortpuffer, keine bestätigte Befehlswarteschlange.

Der Status enthält `urlaubAktiv` (Boolean), `urlaubTemperatur` (Zahl in °C) und die Betriebsartkennung `U`. `atRegelung` bleibt die normale ausgewählte Regelungsart (0/1/2); bei aktivem Urlaub ist die wirksame Regelung dennoch Raumregelung. Für eine vollständige Interpretation beide Felder berücksichtigen.

## Speicherung und Prüfung

Modus und Temperatur bleiben nach Neustart erhalten. Die EEPROM-emulierte Speicherung wurde am Ende um Temperatur an Adresse 160 und Aktivflag an Adresse 168 auf 176 Bytes erweitert. Bestehende Adressen blieben gleich. Anfangswert ist in `config.h` als `URLAUB_DEFAULT_TEMP` definiert.

Build, lokale Regelungs-/Speicherprüfungen und Webprüfungen sind erfolgreich. Upload und die neue Auswahlreihenfolge wurden vom Betreiber bestätigt. Die vollständige Urlaubsprüfung einschließlich MQTT, Speichererhalt nach Neustart und aller Sensorfehlerkombinationen steht noch aus.
