# MQTT

## Verbindung und Themenpräfix

Die anfänglichen Vorgaben für Broker, Port, Benutzername, Passwort, Client-ID und
Themenpräfix stehen in der lokalen `src/secrets.h`. Diese Datei wird nicht veröffentlicht.
**Server, Port, gemeinsamer Basispfad und optionale Broker-Zugangsdaten lassen sich
nach Web-Anmeldung ändern** und bleiben nach erfolgreichem Test gespeichert. Ein
gespeicherter Datensatz hat beim Start Vorrang; die Client-ID bleibt eine lokale
Firmware-Vorgabe. Beide Zugangsdaten leer bedeutet Verbindung ohne Broker-Anmeldung.
Details zu Beibehalten, Migration und Rückfall: [Anmeldung und Netzwerk](https://github.com/cperners/heizung/wiki/Anmeldung-und-Netzwerk). Test- und
Produktionsgerät benötigen weiterhin getrennte Gerätekennungen und passende Themen.

Im Folgenden bezeichnet **P** das konfigurierte Präfix einschließlich abschließendem Schrägstrich. Im produktiven Aufbau wird `/SmartHome/Keller/Heizung/` verwendet. Groß-/Kleinschreibung und der führende Schrägstrich gehören zum Thema.

## Empfangene Nachrichten

| Thema | Format | Zweck |
|---|---|---|
| `Pset` | Einfacher Text | Steuerbefehl |
| `PkachelofenTemp` | Zahl mit Dezimalpunkt, etwa `65.4` | Externe Kachelofentemperatur |
| `Pgaszaehler` | Fortlaufender Gesamtzählerstand in m³, etwa `685.300` | Gaszähler |

Für Steuerbefehle: Raw/Text, QoS 1 und Retain aus. Keine Anführungszeichen, zusätzlichen Leerzeichen oder Zeilenumbrüche hinzufügen.

### Regelungsarten

Alle drei Befehle werden auf `Pset` gesendet:

| Nachricht | Gewählter Modus | Bestätigung im JSON-Feld `answer` |
|---|---|---|
| `tin` | Manuell Raumtemperatur | `h_tin` |
| `tau` | Manuell Außentemperatur | `h_tau` |
| `tauto` | Automatik | `h_tauto` |

### Betriebsarten

| Nachricht auf `Pset` | Wirkung | Antwort |
|---|---|---|
| `setwinter` | Automatikbetrieb | `h_winter` |
| `setboiler` | Nur Boiler | `h_boiler` |
| `setheizung` | Nur Heizung | `h_heizung` |
| `setoff` | Aus | `h_aus` |

### Weitere bestehende Befehle

Der Code enthält außerdem `up`, `down`, `save`, `normal`, `party`, `seton`, `ntpupdate` und numerische Einstellbefehle. Die Namen sind teilweise historisch: **`save` speichert nicht die Einstellungen, sondern senkt beide Wunschtemperaturen um 2 °C.** `up` erhöht beide um 0,2 °C; `down` senkt den Tagwert um 0,2 und den Nachtwert um 0,1 °C. `party` erhöht beide um 2 °C, `normal` lädt die gespeicherten Werte. Für normale Einstellungen ist das Webformular mit geprüfter Speicherbestätigung vorzuziehen.

## JSON-Status

Der Status wird ungefähr alle zehn Sekunden auf **`PJDATA`** veröffentlicht, sofern die MQTT-Verbindung besteht. Der Versand verwendet QoS 1 und Retain. Retain bedeutet, dass ein neu verbundener Empfänger zunächst auch einen älteren gespeicherten Status erhalten kann.

| Feld | Bedeutung |
|---|---|
| `S0Kessel`, `S1Vorlauf`, `S2Aussen`, `S3Kueche`, `S4Boiler` | Temperaturvariablen der fünf Fühler |
| `T0Room`, `T1Boiler`, `T2Vorlauf` | Aktiver Raum-, Boiler- bzw. Vorlaufsollwert |
| `Day`, `Night` | Tag- und Nachtbeginn |
| `BrennerRelais`, `HeizungsRelais`, `BoilerRelais` | Ausgangszustände als Text `"0"` oder `"1"` |
| `MischerAufRelais`, `MischerZuRelais` | Mischer-Ausgangszustände als Text `"0"` oder `"1"` |
| `atRegelung` | Gewählter Regelungsmodus als Zahl: 0 manuell Raum, 1 manuell Außen, 2 Automatik |
| `betriebsart` | Bestehende Betriebsartkennung |
| `answer` | Letzte noch nicht ausgegebene Befehlsantwort; sonst `---` |
| `U0Uptime`, `B0Brenner`, `Uhrzeit` | Laufzeit, Brenner-Laufzeitzähler und Zeitangabe |
| `WlanRetry`, `WlanRSSI` | WLAN-Diagnose |
| `tvmax`, `taumin`, `n`, `PumpenNachlauf` | Weitere Regelungswerte |

Seit der jüngsten Ergänzung beschreibt `atRegelung` den **gewählten Modus**. Bei Automatik steht dort immer 2; daraus lässt sich die gerade wirksame Raum-/Außenregelung nicht direkt ablesen. Das zusätzliche Textfeld `regelungsModus` wird nicht gesendet.

Die JSON-Temperaturvariablen enthalten keine eigene Gültigkeitskennzeichnung. Für die Bewertung eines Sensorfehlers müssen die separaten Sensorthemen berücksichtigt werden; ein Zahlenwert in JSON allein bestätigt keinen gesunden Fühler.

### Befehlsbestätigung

Die Antwort erscheint in der nächsten JSON-Statusmeldung und kann daher ungefähr einen Sendezyklus später kommen. Der aktive Code veröffentlicht sie **nicht auf einem eigenen `Panswer`-Thema**. Das Antwortfeld ist ein einzelner Puffer: Bei mehreren Befehlen vor dem nächsten Versand kann eine spätere Antwort eine frühere überschreiben. Es ist keine Bestätigung jeder einzelnen Anfrage.

## Separate Sensormeldungen

| Thema | Inhalt |
|---|---|
| `Psensorstatus/kessel` | Temperatur mit einer Nachkommastelle oder `SENSORFEHLER` |
| `Psensorstatus/vorlauf` | Wie oben |
| `Psensorstatus/aussen` | Wie oben |
| `Psensorstatus/raum` | Wie oben |
| `Psensorstatus/boiler` | Wie oben |
| `Pbrennersperre` | Klartext zur Kesselsensor-Sperre |
| `Psensordiagnose/boiler` | Boiler-Lesestatus bzw. Fehlergrund |

Diese Themen verwenden QoS 1 und Retain. Sie werden bei Änderungen und nach einer erneuten Verbindung veröffentlicht; Sendeversuche werden auf höchstens einmal pro Sekunde begrenzt.

## Gasverbrauch

Der Tagesverbrauch ist die Differenz zwischen aktuellem Gesamtstand und Tagesbasis. Die Basis wird gespeichert. Falls um Mitternacht keine Messung vorliegt, beginnt die Erfassung mit der ersten neuen, nicht als Retain empfangenen Meldung des Tages. Ein alter Retain-Wert setzt keine neue Tagesbasis. Rückläufige Zählerstände werden verworfen. Die Webseite zeigt drei Nachkommastellen; es handelt sich um m³, nicht um kWh.

## Empfangsgrenzen

MQTT-Nachrichten werden im Callback geprüft und in eine Warteschlange übernommen. Die Hauptschleife verarbeitet sie. Aufgeteilte Nachrichten, leere Nachrichten, eingebettete Nullzeichen und Payloads ab 64 Bytes werden verworfen. Kachelofentemperaturen haben eine zusätzliche engere Längenprüfung. Eine volle Warteschlange führt zum Verwerfen neuer Nachrichten. QoS 1 kann doppelte Zustellung bedeuten; relative Befehle wie `up` sind deshalb nicht generell gegen Wiederholung abgesichert.

## Laufzeitdiagnose im JSON

Das Objekt `diagnostics` wird im bestehenden Zehn-Sekunden-JSON mitgesendet:

| Feld | Einheit und Bedeutung |
|---|---|
| `heapFreeBytes` | Aktuell freier 8-Bit-Heap in Bytes |
| `heapMinBytes` | Niedrigster freier Heap laut Heap-Verwaltung seit Start, Bytes |
| `heapLargestBlockBytes` | Größter aktuell zusammenhängender freier Block, Bytes |
| `loopRecentMaxMs` | Größter Schleifenstart-Abstand im zuletzt abgeschlossenen Messfenster von ungefähr einer Sekunde, ms |
| `loopMaxMs` | Größter erfasster Schleifenstart-Abstand seit Beginn der Schleifenmessung, ms |
| `loopOver100ms` | Anzahl erfasster Abstände über 100 ms seit Beginn der Schleifenmessung |

Die Schleifenmessung beginnt in `loop()` und umfasst nicht die komplette Setup-Dauer. Das jüngste Fenster wird beim MQTT-Versand abgelesen; nicht jedes Ein-Sekunden-Fenster wird über MQTT übertragen. Speicherwerte sind Momentaufnahmen, keine vollständige Aufzeichnung jedes kurzfristigen Engpasses.

Kachelofenmeldungen werden nach mehr als **21 Minuten** ohne gültige Aktualisierung als veraltet behandelt.

## Einheitliche Betriebsarten und neue Urlaubskommandos

`setoff`, `seton`, `setboiler`, `setwinter`, `setheizung` und `seturlaub` verwenden dieselbe Speicherfunktion wie die Web-Betriebsarten. Vorher änderten ältere Befehle die Laufzeitwerte direkt und prüften den Speichererfolg nicht. Jetzt werden neue Werte zuerst gespeichert und erst danach aktiv. Bei Fehler bleibt der bisherige Modus erhalten, Antwort `h_save_error`. Wiederholungen eines in diesem Lauf bereits erfolgreich gespeicherten Modus vermeiden weitere Flash-Schreibvorgänge.

Die Urlaubskommandos und Statusfelder sind auf [Urlaubsbetrieb](https://github.com/cperners/heizung/wiki/Urlaubsbetrieb) beschrieben. `urlaubTemp:16.5` setzt nur die Urlaubstemperatur. `urlaubAktiv` kennzeichnet den Vorrang der Urlaubs-Raumregelung gegenüber der normalen Auswahl in `atRegelung`.

Die Befehlsantwort bleibt nun im Puffer, solange der MQTT-Client den Statusversand ablehnt oder der Status nicht erzeugt werden kann. Erst eine erfolgreiche Annahme zum Versand leert den Puffer. Dies ist keine Broker-Quittierung und schützt weiterhin nicht vor dem Überschreiben durch einen späteren Befehl.

## OTA-Objekt

Der reguläre JSON-Status enthält zusätzlich `ota`:

| Feld | Bedeutung |
|---|---|
| `stage` | Beobachtete Phase: Start angefordert, bereit, Übertragung, Erfolgsmeldung, Fehler, bereits offen oder seit 30 Sekunden kein Fortschritt |
| `attempts` | Vom Start-Callback beobachtete Versuche seit Neustart |
| `bytesWritten` | Übertragene Firmwarebytes laut Fortschritts-Callback |
| `httpContentLength` | HTTP-Multipart-Länge einschließlich Verwaltungsdaten; nicht identisch mit Dateigröße |
| `errorCode`, `error` | Fehlercode und Fehlertext, soweit vom Update-Framework geliefert |
| `activityAgeMs` | Alter der letzten beobachteten Callback-Aktivität |

Die Diagnose greift nicht in einen Upload ein und bricht ihn nicht automatisch ab. Ein erfolgreicher Abschluss kann wegen des anschließenden Neustarts nur kurz sichtbar sein oder vor dem nächsten MQTT-Zyklus verschwinden. Das Sendeintervall bleibt ungefähr zehn Sekunden.

## Ergänzte Boiler-Statuswerte

Der regelmäßige JSON-Status enthält neben `T1Boiler` (Boiler-Solltemperatur) nun `boilerEinschaltdifferenz` und `boilerLadestartUnter`, jeweils als Zahlen in Grad Celsius. `boilerLadestartUnter` ist Solltemperatur minus Einschaltdifferenz. Das Sendeintervall bleibt unverändert.

Die farbige Differenzanzeige Kessel minus Boiler ist eine Webanzeige und fügt kein eigenes MQTT-Feld hinzu. Die neuen Webformulare ergänzen keine neuen MQTT-Kommandos. Historische Temperaturkommandos sind damit nicht automatisch auf die neue geprüfte Web-Speicherung umgestellt.

## Restwärme- und Wiederanlaufdiagnose

| Feld | Bedeutung |
|---|---|
| `restwaermeAktiv` | Aus befindet sich im Restwärmepfad; tatsächliche Ausgänge können zusätzlich durch Fehlerbedingungen begrenzt sein |
| `restwaermeZieltemperatur` | Gespeicherte Kessel-Zieltemperatur, Standard 35 °C, Webbereich 30–40 °C |
| `recovery.resetReason` | Neustartgrund |
| `recovery.previousLoopPhase` | Grobe vorherige Programmphase, soweit erhalten und validiert |
| `recovery.wifiDisconnects` | WLAN-Abbrüche seit Start |
| `recovery.wifiReconnectAttempts` | Vom Programm ausgelöste WLAN-Wiederanläufe seit Start |
| `recovery.wifiLastDisconnectReason` | Zuletzt erfasster WLAN-Abbruchgrund; 0 vor dem ersten Abbruch |
| `recovery.watchdogInitResult`, `recovery.watchdogAddResult`, `recovery.watchdogStatusResult` | Ergebnisse der Watchdog-Einrichtung/Registrierungsprüfung |
| `recovery.watchdogTimeoutSeconds` | Konfigurierte Watchdogfrist, derzeit 200 Sekunden |

Die Restwärmefunktion setzt die Betriebsart nicht auf Automatik: Sie bleibt Aus. Die normale Moduswahl in `atRegelung` wird ebenfalls nicht überschrieben. Die Restwärmeregelung verwendet unabhängig davon die Heizkurve. Es wurde kein neuer MQTT-Befehl für die Restwärme-Zieltemperatur ergänzt. Das Statusintervall bleibt ungefähr zehn Sekunden.

## Schaltprotokoll fuer externe Analyse

Neben JDATA gibt es nun ein nicht retained gesendetes Ereignisthema fuer jeden
GPIO-Wechsel aller fuenf Ausgaenge, mit Erfassungszeit, Startkennung und Sequenz.
Format, Puffergrenzen und die Node-RED-Funktion mit fuenf Ausgaengen: [MQTT-Protokoll der Schaltausgaenge](https://github.com/cperners/heizung/wiki/MQTT-Schaltereignisse).
