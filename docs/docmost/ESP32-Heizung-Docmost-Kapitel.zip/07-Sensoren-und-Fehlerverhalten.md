# Sensoren und Fehlerverhalten

## Anschlüsse und Erkennung

Die fünf Temperaturfühler sind einzeln verdrahtet: ein Fühler pro OneWire-Anschluss. Die direkte Gerätekennungs-Abfrage setzt diesen Aufbau voraus; mehrere Fühler an einem Anschluss sind damit nicht vorgesehen.

| Fühler | GPIO im aktuellen Code | Index |
|---|---|---|
| Kessel | 32 | 0 |
| Vorlauf | 25 | 1 |
| Außen | 26 | 2 |
| Küche/Raum | 27 | 3 |
| Boiler | 33 | 4 |

Die Erkennung speichert den Sensortyp pro Fühler. Unterstützt werden die Familien DS18S20, DS18B20 und DS1822. Fehlgeschlagene Typ-Erkennung wird nach etwa 30 Sekunden erneut versucht. Der Boiler verwendet einen vollständigen OneWire-Leseweg statt der früheren Mischung aus eigener Handroutine und Bibliothek.

## Gültigkeitsprüfung

Die Messung prüft Anwesenheit, Datenblock und Prüfsumme. Komplett aus Null oder 255 bestehende Daten werden verworfen. Werte müssen endlich sein und im Bereich −55 bis 125 °C liegen. Ein Messwert gilt bei fehlerhafter Lesung oder mehr als 30 Sekunden ohne gültige Aktualisierung als ungültig.

Webseite und MQTT-Sensorthemen zeigen Sensorfehler; das LCD zeigt X. Die letzte Temperaturvariable kann intern bestehen bleiben, ist aber bei Ausfall nicht als gültiger Messwert zu interpretieren.

## Brenner

Bei ungültigem oder zu altem Kesselsensor wird der Brenner zentral gesperrt. Eine Anforderung aus einer anderen Funktion kann diese Sensorsperre nicht übergehen. Der Sperrstatus erscheint auf der Webseite und per MQTT.

## Mischer

Außerhalb der Betriebsart Aus ist bei einem Vorlaufsensorfehler die anlagenspezifisch gewünschte Reaktion:

1. Mischer einmalig für 20 Sekunden öffnen.
2. Danach beide Stellrichtungen abschalten und weitere Bewegungen sperren.
3. Kommt vorher ein gültiger Messwert, endet die Fehler-Auffahrt und die normale Regelung wird wieder freigegeben.

Ohne Sensor startet diese Auffahrt auch nach einem Neustart. Öffnen bedeutet bei dieser Anlage mehr heißes Kesselwasser im Heizkreis. Ein unabhängiger Temperaturbegrenzer wurde vom Betreiber bestätigt. Diese Reaktion ist keine allgemeine Empfehlung für andere Anlagen; sie muss zum jeweiligen hydraulischen Aufbau passen. Die Software-Zeitbegrenzung hängt von der laufenden Hauptschleife ab.

## Pumpen

| Ausgang | Zugeordnete Sensoren |
|---|---|
| Boilerpumpe | Kessel und Boiler |
| Heizungspumpe bei kombinierter Raumregelung in Automatik/Nur Heizung | Kessel, Vorlauf, Außen und Raum |
| Heizungspumpe bei Außenregelung oder Restwärme | Kessel, Vorlauf und Außen |
| Heizungspumpe bei Urlaub | Kessel, Vorlauf und Raum |

Bei einem zugeordneten Fehler laufen **nur bereits eingeschaltete Pumpen** bis zu zehn Minuten nach. Ausgeschaltete Pumpen bleiben aus. Nach Ablauf bleibt die betroffene Pumpe gesperrt. Gültige Messwerte geben die Regelung wieder frei.

Dieser Fehlernachlauf ist von den übrigen normalen Pumpenfunktionen zu unterscheiden. Seine tatsächliche Wirkung muss am Anlagenaufbau geprüft werden, einschließlich Restwärmeabfuhr und Wechsel der Regelungsart.

## Heizkurve

Die Berechnung prüft Eingaben und Rechenergebnisse, vermeidet ungültige Divisionen und begrenzt den Vorlaufsollwert auf die eingestellte Maximaltemperatur. Eine ungültige Berechnung erzeugt keine Heizanforderung.

## Grenzen

Fehlersperren decken definierte Softwarefälle ab. Relaiskontaktfehler, falsch angeschlossene Aktoren, elektrische Störungen oder eine mechanisch blockierte Pumpe werden nicht durch eine echte Aktorrückmeldung erkannt. Für die Anlagenbewertung bleiben unabhängige Hardware-Schutzfunktionen und Prüfungen notwendig.

## Restwärmebetrieb und Betriebsart Aus

Der Brenner wird in Aus unabhängig von gespeicherten Wärmeanforderungen gesperrt. Bei warmem oder noch nicht gültig erfasstem Kessel wird die Restwärmephase ausgewählt. Für eine reguläre Wärmeabfuhr müssen Kessel, Vorlauf und Außensensor gültig sein; der Raumfühler ist hierfür nicht erforderlich. Ungültiger Kesselsensor gilt nicht als bestätigte Abkühlung und löst deshalb keine blinde Schließfahrt aus.

In dieser Phase bleibt die vorhandene Vorlaufsensor-Fehlerreaktion aktiv: einmalige 20-Sekunden-Auffahrt, danach Sperre. Die bestehende Pumpenfehlerlogik lässt nur bereits laufende Pumpen begrenzt nachlaufen; ausgeschaltete Pumpen starten bei Sensorfehler nicht. Bei ungültigen Heizkurvenparametern erfolgt keine normale Pumpen-/Mischeranforderung aus der Restwärmeregelung.

Bei gültigem Kesselwert höchstens Restwärmeziel (Standard 35 °C, einstellbar 30–40 °C) endet die geregelte Wärmeabfuhr. Die anschließende zeitlich begrenzte Schließfahrt hat wie zuvor Vorrang vor normaler Initialisierung und Vorlaufsensor-Auffahrt; der Vorlaufsensor ist für diese bereits temperaturfreigegebene Schließfahrt keine zusätzliche Bedingung. Wird der Kessel erneut warm oder ungültig, wird die Schließfahrt abgebrochen und wieder der Restwärmepfad mit seinen Fehlerprüfungen verwendet.

Die Zieltemperatur ist gespeichert, der Standard `MISCHER_AUS_KESSEL_MAX_TEMP` bleibt 35.0f. Die Schließdauer `MISCHER_AUS_ZUFAHRT_MINUTEN` bleibt zwei Minuten. Die Überwachung läuft in Software und ersetzt keine unabhängige Hardwareabschaltung. Details und Testgrenzen: [Geregelte Restwärmeabfuhr in Betriebsart Aus](https://github.com/cperners/heizung/wiki/Restwaermebetrieb).

## Grenzen der normalen Boiler- und Mischerregelung

Die Boilerpumpe erhält im fehlerfreien normalen Ladebetrieb keine Anforderung bei Kesseltemperatur höchstens Boilertemperatur. Der vereinbarte begrenzte Fehlernachlauf und die Pumpenschutzbewegung sind davon getrennte Ausnahmen.

Normale Mischerimpulse haben einen vom LCD-Zähler unabhängigen Zeitstopp und eine konfigurierbare Ruhezone von standardmäßig ±0,5 °C. Die Regelung stoppt normale Stellbewegungen, wenn kein aktiver Heizkreis mehr vorliegt. Sonderfahrten behalten ihre gesonderte Zuordnung und Fehlerreaktion. Ausgänge und echte Bewegung sind weiterhin nicht identisch.
