# Installation und Updates

## Konfigurationsdateien

- `src/config.h`: Pins, Zeitkonstanten, Fühleroffsets, NTP-Server und weitere Einstellungen.
- `src/secrets.h`: anfängliche WLAN-, MQTT- und Web-Zugangsdaten, lokal und vom Git-Upload ausgeschlossen.
- Auf dem Gerät gespeicherte Web-Passwörter und Netzwerkdaten haben beim Start Vorrang vor den Firmware-Vorgaben.
- `src/secrets.example.h`: Vorlage ohne echte Zugangsdaten.
- `platformio.ini`: Board, Framework und Bibliotheken.

Das aktuelle Ziel verwendet PlatformIO-Umgebung `nodemcuv2`, Board `esp32dev` und Arduino-Framework. Der Umgebungsname ist historisch und bezeichnet hier keinen ESP8266.

Die produktive Kopie verwendet DHCP. Eine DHCP-Reservierung ist hilfreich, wenn ein Reverse Proxy dauerhaft auf denselben ESP32 zeigen soll. Test- und Produktionsgerät dürfen nicht unbeabsichtigt dieselbe Gerätekennung oder die gleichen produktiven MQTT-Steuerthemen verwenden.

## Build

Im Projektordner:

```sh
pio run -e nodemcuv2
```

Das Firmware-Abbild liegt anschließend unter `.pio/build/nodemcuv2/firmware.bin`. Für OTA wird die **BIN-Datei** verwendet, nicht die ELF-Datei. Erst ein erfolgreicher Build bestätigt die Kompilierung; Funktions- und Laufzeittests müssen anschließend am Gerät erfolgen.

Zugangsdaten werden in die Firmware kompiliert. Deshalb gehören auch produktive BIN-Dateien nicht in ein öffentliches Repository oder einen öffentlichen Download.

## OTA-Ablauf

1. Aktuelle Konfiguration und Zugangsdaten der richtigen Projektkopie prüfen.
2. Bekannte funktionierende Firmware für einen Rückweg aufbewahren.
3. Einstellungen dokumentieren, etwa über LCD-Fotos. Die Firmwaredatei ist keine Sicherung der aktuellen Geräteeinstellungen.
4. Neu bauen und den erfolgreichen Abschluss prüfen.
5. Die Update-Seite des Geräts unter `/update` öffnen und die passende BIN-Datei einspielen. Der aktuelle Stand schützt diesen Update-Zugang auf ausdrücklichen Wunsch nicht mit einem Passwort.
6. Neustart abwarten, Webseite neu laden und Fühler, Betriebsart, Regelungsart und Ausgangszustände prüfen.
7. Gespeicherte Einstellungen mit der Sicherung vergleichen.

Die Update-Seite dient zum Einspielen; eine vollständige Sicherung von Flash und Einstellungen ist darüber nicht implementiert. Ein Rückweg setzt voraus, dass das Gerät und seine Update-Seite noch erreichbar sind. Bei einem nicht startenden oder nicht erreichbaren Gerät reicht eine vorhandene alte BIN-Datei allein nicht für eine Fernwiederherstellung.

## Web-Anmeldung und Netzwerkänderungen

Die Web-Anmeldung schützt die Einstellungsformulare mit Ausnahme von Regelung und
Betriebsart. Der Update-Zugang bleibt davon unabhängig offen; ein Passwortwechsel
aktiviert dort keine Anmeldung. Somit kann ein Gerät mit Netz-Zugriff auch ein Update
anstoßen. Bereits gespeicherte Passwörter bleiben beim Upgrade auf bis zu 64 UTF-8-Bytes
zulässige Anmeldepasswörter erhalten. WLAN und MQTT werden nach erfolgreichem Verbindungstest
in Preferences/NVS gesichert. Bedienung, optionale Broker-Zugangsdaten und Rückfall:
[Anmeldung und Netzwerk](https://github.com/cperners/heizung/wiki/Anmeldung-und-Netzwerk).

## Netzwerkzeit

Die Zeit wird über die native ESP32-Zeitfunktion von drei konfigurierten NTP-Servern bezogen. Nach Neustart wird auf gültige Zeit gewartet; danach läuft die Systemzeit lokal weiter. Zeitprogramme werden vor gültiger Zeit nicht ausgewertet.

Die NTP-Karte fragt die Server zusätzlich einzeln ab und zeigt Abweichung zur ESP32-Uhr, Antwortlaufzeit und Alter der Messung. Diese Diagnoseabfragen stellen die Systemzeit nicht selbst um.

## Lokales HTTPS

HTTPS wird im vorhandenen Aufbau durch einen vorgeschalteten Nginx Proxy Manager auf einer Debian-VM übernommen:

```text
Browser → HTTPS-Proxy → HTTP zum ESP32
```

Der lokale DNS-Name zeigt auf den Proxy. Dessen Weiterleitungsziel bleibt die ESP32-Adresse mit HTTP-Port 80. Der Proxy verwendet ein Zertifikat einer lokalen Zertifizierungsstelle. Clientgeräte müssen dem öffentlichen Stammzertifikat vertrauen. Der private Schlüssel der Zertifizierungsstelle bleibt geschützt auf dem Server.

Die Verschlüsselung endet am Proxy; die Verbindung vom Proxy zum ESP32 bleibt HTTP. Zertifikatsvertrauen fügt keine Benutzeranmeldung zur Heizungsseite hinzu. Zertifikate müssen vor Ablauf erneuert und private Schlüssel gesichert werden.

## Nach dem Update

Neue Oberflächenbestandteile können durch Browser-Caches verzögert erscheinen, insbesondere das Favicon. Die Webseite neu öffnen und bei Bedarf Browserdaten gezielt aktualisieren. Vorher prüfen, ob tatsächlich die richtige Firmware und die richtige Geräteadresse verwendet wurden.

## Wiederkehrende OTA-Abbrüche

Im Betrieb traten wiederholt `Update failed – No Error` und Verbindungsabbrüche auf, auch ohne HTTPS-Proxy. Spätere Versuche waren erfolgreich. Eine beschädigte BIN-Datei wurde dabei nicht nachgewiesen; die lokal geprüften Bilder hatten gültige Prüfsummen und interne Hashes. Die Ursache ist weiterhin offen.

Ein möglicher Codepfad ist ein bereits geöffneter Update-Vorgang: Das Framework kann einen erneuten Start ohne gesetzten Fehlercode ablehnen. Das wurde als Möglichkeit gefunden, am Gerät aber noch nicht bewiesen.

Die neue OTA-Diagnose ist auf der Hauptseite unter Systemdiagnose, über `/ota-status` und im MQTT-Objekt `ota` zugänglich. Sie beobachtet Start, Fortschritt und Abschluss. Nach erfolgreichem Neustart beginnt die Beobachtung neu. Kein Fortschritt nach 30 Sekunden ist eine Diagnose, keine automatische Abbruchanweisung. Weitere Uploadversuche nicht parallel starten; Fehlermeldung, Diagnose und Erreichbarkeit festhalten, bevor neu gestartet wird.

## Fester OTA-Dateiname

Die bereitgestellte aktuelle Produktionsdatei heißt immer **heizung-produktion-ota.bin** und wird bei einem neuen Build aktualisiert. Keine wechselnden Funktionsnamen sind für den normalen Upload nötig. Die Datei enthält die lokal eingebauten Zugangsdaten und wird nicht ins öffentliche Repository hochgeladen. Gerätetests sind nach jedem relevanten Update separat erforderlich.
