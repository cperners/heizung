# Architektur

## Datenfluss

```text
Sensoren / MQTT / Webeingaben
              ↓
       Hauptschleife
              ↓
  Messwertprüfung und Regelungslogik
              ↓
 Sensorsperren / Pumpennachlauf / Mischer
              ↓
      Geschaltete Ausgänge
              ↓
 LCD / MQTT-Status / Web-Status-Snapshot
```

Die Darstellung vereinfacht den Ablauf. Netzwerk-Callbacks und NTP-Diagnose haben eigene Ausführungskontexte. Einstellaufträge werden gezielt an die Hauptschleife übergeben, um direkte konkurrierende Änderungen zu reduzieren.

## Quellcodeaufteilung

`src/main.cpp` bindet Bibliotheken, öffentliche Schnittstellen und Firmwareabschnitte ein.

| Eigenständiges Modul | Aufgabe |
|---|---|
| `src/web/page.cpp` | HTML, CSS und JavaScript |
| `src/diagnostics/cpu_load.cpp` | Grobe CPU-Schätzung je Kern |
| `src/ntp_diagnostics/ntp_diagnostics.cpp` | Separate NTP-Diagnose |

Die Dateien unter `src/firmware/` sind `.inc`-Implementierungsabschnitte: `shared_state`, `runtime_support`, `web_access`, `wifi_settings`, `mqtt_settings`, `setup`, `loop`, `web_status`, `web_handlers`, `network`, `mqtt`, `clock`, `uptime`, `sensor_reading`, `sensor_bus`, `heating`, `mixer`, `lcd_menu`, `lcd_display` und `serial_console`.

Sie werden in derselben Übersetzungseinheit eingebunden und teilen weiterhin globale Variablen. Die Struktur trennt Zuständigkeiten sichtbar, ist aber noch keine vollständig unabhängige Modularchitektur. `.inc`-Dateien dürfen nicht einfach zusätzlich als `.cpp` kompiliert werden.

## Webstatus und Eingaben

Die Hauptschleife erzeugt ungefähr einmal pro Sekunde einen JSON-Snapshot. Der Webserver liefert dessen Kopie aus. Die Webseite fragt diesen einmal pro Sekunde ab; eine noch laufende Anfrage verhindert eine zweite gleichzeitige Anfrage.

Wunschtemperaturen und Zeiten werden in der Hauptschleife gespeichert. Eine Anfragekennung ordnet die Speicherbestätigung zu. Änderungen an Regelungsart und Kachelofen-Schaltschwellen werden ebenfalls kontrolliert übergeben. Die Speicherbestätigung der Wunschtemperaturen ist nicht mit der MQTT-Befehlsantwort gleichzusetzen.

## CPU-Schätzung und Laufzeit

Die Laufzeit im Web basiert auf einem 64-Bit-Zeitgeber. Die CPU-Anzeige beobachtet Leerlauf je Kern und mittelt über fünf Sekunden. Sie zeigt Abschnitte ohne beobachteten Leerlauf, keine exakte CPU-Zeitmessung. Kurze Rechenarbeit innerhalb eines Abschnitts kann unterschätzt werden. Die Framework-Laufzeitstatistik ist in diesem Build nicht aktiviert.

## Speicherung

Temperaturen, Zeitprogramm und weitere Bestandsparameter werden in EEPROM-emulierter Speicherung abgelegt. Bei ungültigen gespeicherten Einstellungen werden vorhandene Standardwerte verwendet. Die Tagesbasis des Gaszählers verwendet Preferences. Nicht jede historische MQTT-Einstellung hat dieselbe geprüfte Speichertransaktion wie das neue Webformular.

## Bibliotheken

| Bibliothek | Konfiguration |
|---|---|
| ElegantOTA | 4.0.0, asynchroner Betrieb |
| ESPAsyncWebServer | 3.12.1 |
| AsyncTCP | 3.5.0 |
| ArduinoJson | 7.4.3 |
| OneWire | 2.3.8 |
| AsyncMqttClient | Bereich `^0.9.0` |
| Keypad, Ticker | In PlatformIO ohne feste Versionsangabe |
| LCD-/I2C-Tastaturbibliotheken | Lokale Dateien mit bestehenden Hardwareanpassungen |

Diese Angaben beschreiben die Projektkonfiguration, nicht eine Aussage über die aktuell neueste Veröffentlichung jeder Bibliothek. Ungebundene Versionsangaben können bei einer Neuinstallation andere Versionen ergeben.

## Ergänzte Laufzeitdiagnose

`src/firmware/runtime_diagnostics.inc` erfasst Speicherzustand und Schleifenabstände. Die Hauptschleife aktualisiert die Werte; Webstatus und MQTT lesen diese Diagnose. Speicherwerte werden ungefähr einmal pro Sekunde mit derselben Heap-Kategorie `MALLOC_CAP_8BIT` abgerufen.

Der nicht blockierende Aus-Zustand in `mixer.inc` entscheidet vor der normalen Regelung zwischen geregelter Restwärmeabfuhr und abschließender Schließfahrt. `kein_Betrieb()` hält Wärmeanforderungen und Brenner aus; `runOffHeatRecovery()` verwendet die Heizkurve unabhängig von der ausgewählten Raum-/Außenregelung. Die Heizkurvenregelung bei Raum-/Außen-Heizbedarf und die Restwärme verwenden denselben Mischerimpulsregler. Eine zentrale Ausgangssperre verhindert Brenneranforderungen in Aus.

Der Kachelofen-Timeout ist aktuell noch als 21-Minuten-Konstante in `shared_state.inc` definiert. Eine spätere Auslagerung nach `config.h` wurde vorgemerkt und ist noch nicht umgesetzt.

## Optimierung von Webausgabe und MQTT

`web_page_response.inc` erzeugt eine Antwort mit festgehaltenen Platzhalterwerten. `src/web/template_stream.h` liefert die HTML-Vorlage abschnittsweise aus. Es werden ausschließlich bekannte Tokens ersetzt; Prozentzeichen in CSS, JavaScript und Werten bleiben erhalten. Eine vollständige HTML-String-Kopie pro Anfrage entfällt.

Webstatus und MQTT behalten ihre JSON-Dokumente und Variant-Speicherpools zwischen Zyklen. Bei einem Allokationsfehler wird das jeweilige Dokument zur Erholung zurückgesetzt. Das verringert Speicherbewegungen, ist aber kein Beweis, dass die Langzeitverzögerung behoben ist. Die dauerhaft gehaltenen Pools verändern die Speicher-Ausgangswerte gegenüber der Vorversion.

`ota_diagnostics.inc` beobachtet die ElegantOTA-Callbacks und ergänzt in der Hauptschleife Fehler-/Fortschrittsinformationen. Ein eigener Mutex schützt die Momentaufnahme. Es werden keine automatischen Abbrüche oder zusätzlichen Neustarts ausgelöst. Die Heizungs- und Fehlersperrlogik wurde durch diese Optimierung nicht verändert.

Betriebsarten verwenden für Web und alle sechs MQTT-Modusbefehle `applyOperatingMode()`. Die älteren LCD-Einstellwege sind damit nicht vollständig vereinheitlicht. Die Struktur bleibt eine Mischung eigenständiger Module und gemeinsam eingebundener Implementierungsabschnitte.

## Web-Einstellungen und Ausgangssymbole

Boiler-Solltemperatur/Einschaltdifferenz und Vorlaufmaximum/Kurvensteilheit werden als getrennte, begrenzte Anfragen unter dem vorhandenen kritischen Abschnitt übernommen. Die Hauptschleife speichert die jeweilige Einstellungsgruppe zuerst und ändert die Laufzeitwerte nur bei Erfolg. Bei Fehler wird der EEPROM-Puffer auf die bisherigen Werte zurückgesetzt. Anfragen nutzen eindeutige Kennungen und den bestehenden Ergebnisring mit acht Plätzen; offene Ergebnisse werden nicht überschrieben. Alte Clients können die zusätzlichen Parameter weglassen.

Die Boiler-Differenz wird nur mit zwei gültigen Sensoren angezeigt. Ausgangssymbole verwenden die vorhandenen fünf Ausgangszustände der gemeinsamen Web-Statusabfrage. Die Symbole sind lokal eingebettete SVGs; zusätzliche Icon-Abfragen werden nicht benötigt.

`updateMischerBoilerMode()` betreut in jeder Schleife die einmalige Boiler-Schließfahrt. Nach Abschluss der ersten Fahrt werden Referenztemperatur und Wartebeginn gespeichert. Nach zehn Minuten entscheidet ein einmaliger Vergleich über genau eine Nachfahrt. Der Abschluss bleibt bis zum nächsten Eintritt gespeichert, damit ein Timerüberlauf keine neue Fahrt startet. Beim Übergang nach Aus bleiben dessen bereits gesetzte Ausgänge erhalten. Sensorfehlerlogik hat Vorrang.

## Gespeicherte Restwärmetemperatur

Die Adresse `EEADDRESS_RESTWAERME_ZIEL` liegt bei 172; ein Float passt damit in den bereits bestehenden EEPROM-Bereich von 176 Bytes. Bestehende Felder werden nicht verschoben. Ein unbekannter oder ungültiger neuer Wert wird auf den Standard 35 °C gesetzt. Das Vorlaufformular übergibt den optionalen Parameter `restwaerme`; die Hauptschleife speichert ihn zusammen mit Vorlaufmaximum und optionaler Kurvensteilheit. Erst ein erfolgreicher Commit aktiviert die Werte. Bei Fehler wird auch der bisherige Restwärmewert im EEPROM-Puffer wiederhergestellt. Alte Clients ohne diesen Parameter ändern ihn nicht.

## WLAN-Wiederanlauf und Neustartdiagnose

Ein erfolgreicher IP-Bezug löscht den ausstehenden WLAN-Wiederverbindungsauftrag. Ein verspäteter Auftrag trennt keine bereits erholte Verbindung. Verbindungsaufrufe erfolgen in der Hauptschleife; Versuche haben mindestens 15 Sekunden Abstand und bleiben auch nach ausbleibenden Treiberevents möglich.

Die Diagnose zählt WLAN-Abbrüche und Wiederanlaufversuche und protokolliert den letzten Abbruchgrund. Die Watchdog-Einrichtung erfasst Rückgabewerte und den tatsächlichen Registrierungsstatus; der konfigurierte Timeout bleibt 200 Sekunden. RTC-Speicher hält eine zuletzt markierte grobe Programmphase für geeignete Software-/Watchdog-Neustarts vor, nicht zuverlässig nach vollständigem Stromausfall. Sie ist kein Stacktrace und kein Beweis für die Fehlerursache. Webstatus und MQTT enthalten diese Angaben.

## Raumregelung mit Heizkurve

`controlSpaceHeating()` ruft bei Raumregelung `chckRoom(kesselReady)` auf. Das Argument erlaubt oder verbietet einen neuen Pumpenstart, ohne die Auswertung eines bereits aktiven Heizkreises zu überspringen. Raum-Sollwert und Hysterese bestimmen den Pumpenzustand; ein laufender Heizkreis regelt den Vorlauf mit der Heizkurve auch unterhalb der bisherigen Kesselfreigabe. In Automatik und Nur Heizung wird die Kurve deshalb auch bei gewählter Raumregelung berechnet und validiert. Urlaub behält den bisherigen Sonderweg.

`heatingPumpSensorFault()` ordnet der kombinierten Raumregelung Kessel-, Vorlauf-, Außen- und Raumsensor zu. Bei Außenregelung und Restwärme wird der Raumfühler nicht zusätzlich benötigt. Bei ungültigen Heizkurvenparametern wird eine normale Pumpenanforderung beendet; Sensorfehlernachlauf bleibt zentral behandelt.

## Zuordnung und Frist normaler Mischerimpulse

`startRegulatedMischerPulse()` merkt Startzeit und aktive Zuordnung eines normalen Impulses. `serviceRegulatedMischerPulse()` wird unabhängig vom Regelungszweig in jeder Hauptschleife aufgerufen. Er beendet den Impuls nach `MISCHER_DRIVE * 1000` Millisekunden oder bei fehlendem aktivem Heizkreis. Die Differenz wird mit 32-Bit-Arithmetik gebildet, damit ein Millisekundenüberlauf korrekt behandelt wird.

`regulateMischerToTarget()` beendet normale Fahrten innerhalb der konfigurierten Ruhezone oder bei umgekehrter erforderlicher Richtung. Neue Impulse starten erst nach dem vorhandenen Wartezähler. `MischerAuf()`, `MischerZu()` und `MischerStop()` übernehmen beziehungsweise löschen die alte Impulszuordnung. Zustandswechsel nach Aus und Sensorfehlerfahrten löschen sie ebenfalls; dadurch beendet der normale Zeitdienst keine längere Sonderfahrt.

## Boiler-Ladefreigabe und Webanzeige

`SetOutPin()` prüft die normale Boileranforderung bei jedem Durchlauf gegen die aktuelle Kessel-Boiler-Differenz. Bei fehlerfreien Sensoren und Kesseltemperatur höchstens Boilertemperatur wird die Anforderung verworfen. Die nachgeschaltete bestehende Sensorfehler- und Pumpenschutzlogik bleibt erhalten.

`vorlaufCalculationDisplay()` liefert den berechneten Vorlauf-Sollwert und die Differenz Ist minus Soll als getrennte Texte. Initiale HTML-Platzhalter und gemeinsame Webstatusfelder werden gleichermaßen bedient. Bei deaktivierter Berechnung, ungültigem Ergebnis oder erforderlichem Sensorfehler erscheinen Hinweise statt irreführender Zahlen. Die zusätzlichen Felder `vorlauf-soll` und `vorlauf-diff` werden über die vorhandene Webstatusabfrage aktualisiert; zusätzliche Browseranfragen sind nicht nötig.

## Web-Anmeldung und gespeicherte Netzwerkprofile

`web_access.inc` verwaltet vier RAM-Sitzungen und die Passwortänderung. Schreibende
Web-Routen prüfen einen Sitzungsschlüssel; die HTML-Sperre ist nur die zusätzliche
Bedienungsebene. Login und Auftragsübergaben laufen im Web-Callback; NVS-Speicherung
und Übernahme des Passworts erfolgen in der Hauptschleife. Das unveröffentlichte
Anfangspasswort ist nach Speicherung nicht mehr maßgeblich. Alte 9-Byte-Passwortdatensätze
werden in die erweiterte Kapazität übernommen.

`wifi_settings.inc` und `mqtt_settings.inc` besitzen getrennte Preferences-Namensräume.
WLAN-Daten werden erst nach stabiler Verbindung, MQTT-Daten nach erfolgreicher
Broker-Verbindung als vollständiger Datensatz gespeichert. Fehler führen zur
bisherigen Konfiguration zurück. MQTT-Callbacks verwenden eine konsistente Momentaufnahme
der Empfangsthemen; während des Wechsels werden Befehle verworfen. Eine Themengeneration
löst die erneute Veröffentlichung unveränderter Sensor-/Sperrstatuswerte aus.

Die neue MQTT-Datensatzversion ergänzt optionale Zugangsdaten und liest weiterhin
die vorherige Version ohne diese Felder. Passwörter werden nicht an den Browser
zurückgesendet. NVS-Verschlüsselung wird durch diese Funktion nicht eingerichtet.
Der Zugriffsschutz erstreckt sich ausdrücklich nicht auf ElegantOTA. Details:
[Anmeldung und Netzwerk](https://github.com/cperners/heizung/wiki/Anmeldung-und-Netzwerk).
