# Tests und Fehlersuche

## Bestätigte Funktionstests

Der Betreiber hat im bisherigen Verlauf unter anderem bestätigt:

- Weboberfläche, MQTT-Empfang und Update-Seite erreichbar.
- Fünf angeschlossene Fühler liefern wieder Werte nach Umstellung der Gerätekennung auf direkte Einzelabfrage.
- Betriebsarten-Auswahl funktioniert.
- Wunschtemperaturen und Kachelofen-Schaltschwellen sind bedienbar; für Schaltschwellen wurde Erhalt nach Neustart bestätigt.
- Tag- und Nachtzeiten sind nach Korrektur der Platzhalter vorbefüllt.
- Mobile Kopfzeile passt auf dem iPhone.
- LCD-Darstellung ohne Wochentag passt.
- Kachelofen-Timeout fällt nach ausbleibenden Meldungen auf inaktiv und automatische Raumregelung zurück.
- Temperaturtrendpfeile passen am Gerät.

Diese Rückmeldungen sind Funktionsprüfungen, keine vollständige Abnahme aller Fehler- und Anlagenzustände.

## Empfohlene Prüfungen

### Nach einer Firmwareänderung

1. Neustart ohne wiederholte Bootschleife prüfen.
2. Alle fünf Sensorwerte auf Plausibilität prüfen.
3. Webstatus und MQTT-Historie mehrere Minuten beobachten.
4. Regelungs- und Betriebsart gezielt umschalten und Anzeige vergleichen.
5. Wunschtemperaturen und Zeiten speichern; nach Neustart auf Erhalt prüfen.
6. LCD-Menü öffnen und zurückkehren: vier vollständige Zeilen ohne Zeichenreste.

### Trendanzeige

- Bei zwei neuen steigenden Messungen Pfeil hoch prüfen.
- Bei zwei fallenden Messungen Pfeil runter prüfen.
- Bei nahezu gleichem Wert waagrechten Pfeil prüfen.
- Wiederholte Webabfragen ohne neue Messung dürfen den Trend nicht zurücksetzen.
- Bei ungültigem oder zu altem Messwert darf kein Trend stehen.

### Langzeittest

Über mehrere Tage Laufzeit, Neustarts, MQTT-Aktualisierung, Webreaktion und Fühlerfehler dokumentieren. Die grobe CPU-Schätzung allein beweist keine ausreichenden Reserven; dynamischer freier Heap und längere Blockierungen sind damit nicht vollständig erfasst. Das Projekt hat noch keine automatisierte vollständige Langzeitmessung.

## Typische Probleme

| Beobachtung | Prüfschritt |
|---|---|
| JSON im MQTT Explorer bleibt scheinbar alt | Suchfilter entfernen, Thema und Historie prüfen; Retain und aktive Verbindung unterscheiden |
| Regelungsmodus im JSON passt nicht | `atRegelung`: 0 Raum, 1 Außen, 2 Automatik; richtige Firmware prüfen |
| Web zeigt Nicht erreichbar/graue LEDs | Netzwerk, Geräteadresse und Statusabfrage prüfen |
| Sensorfehler | Separates MQTT-Sensorthema und bei Boiler die Diagnose ansehen |
| Boiler-Datenblock nur 255 | Leseweg, Verdrahtung und Sensorantwort untersuchen; Fehlerprüfung nicht einfach abschalten |
| HTTPS-Name nicht auffindbar | Lokalen DNS-Eintrag auf Proxy prüfen; VPN kann lokale Namensauflösung stören |
| HTTPS-Verbindung abgelehnt | Proxyadresse, HTTPS-Port und Container prüfen, bevor Zertifikatvertrauen geändert wird |
| Zertifikatswarnung | Name im Zertifikat, Ablauf und Vertrauen der lokalen Zertifizierungsstelle prüfen |
| Chrome scheitert, Safari funktioniert | Lokale Netzwerkfreigabe und browserbezogene DNS-/Verbindungseinstellungen prüfen |

## Bekannte Grenzen und offene Arbeiten

- Eine vollständige Fehlerfallprüfung aller Sensor-/Pumpen-/Mischerkombinationen fehlt.
- MQTT hat einen einzelnen Antwortpuffer; mehrere schnelle Befehle erhalten keine garantierten Einzelbestätigungen.
- JSON-Temperaturen haben keine eigene Sensor-Gültigkeitskennzeichnung.
- Das Tagintervall unterstützt keinen Verlauf über Mitternacht und besitzt strenge Beginn-/Endgrenzen.
- Historische relative MQTT-Befehle sind nicht generell gegen doppelte QoS-1-Zustellung abgesichert.
- Teilbereiche der Firmware teilen weiterhin globale Daten.
- Die CPU-Anzeige ist eine Schätzung, keine exakte Messung.

Änderungen sollten einzeln gebaut, am Testgerät geprüft und erst dann am aktiven System verwendet werden. Beim Fehlertest am aktiven Heizsystem muss die Wirkung auf reale Ausgänge berücksichtigt werden.

## Restwärmeabfuhr bei Aus

Der frühere erste Gerätetest bezog sich auf die alte Warte-/Schließlogik. Die neue geregelte Wärmeabfuhr mit einstellbarer Zieltemperatur ist lokal geprüft, aber noch nicht vollständig am Gerät bestätigt.

1. Bei warmem Kessel von Automatik oder Nur Heizung auf Aus wechseln: Brenner aus, Heizungspumpe an und Vorlauf nach Heizkurve regeln.
2. Vorlaufmaximum und Verhalten bei bereits erreichter Raumtemperatur kontrollieren.
3. Bei höchstens gespeichertem Ziel (Standard 35 °C) muss die reguläre Pumpenanforderung enden und die zweiminütige Schließfahrt beginnen.
4. Danach beide Mischer-Ausgänge aus; bei Wiedererwärmung wieder geregelte Wärmeabfuhr.
5. Zieltemperatur innerhalb 30–40 °C speichern und nach Neustart auf Erhalt prüfen.
6. Betriebsartwechsel muss den Aus-Ablauf abbrechen. Sensorfehlerfälle nur unter kontrollierten Anlagenbedingungen prüfen.

Die Hosttests verwenden tatsächliche Quellfunktionen mit simulierten Sensoren, Ausgängen und EEPROM. Sie prüfen Grenzen bei 30, 35 und 40 °C, Brennersperre, Heizkurve trotz vorheriger Raumregelung, Vorlaufbegrenzung, Mischerimpulse, Schließdauer, Wiedererwärmung und Sensorfehler. Die Speicherprüfung deckt ungültige Werte, unveränderte Einstellungen, Altclients, fehlgeschlagene Commits und die Wiederherstellung des bisherigen Puffers ab. Speicher-/Ablauftests verwenden AddressSanitizer und UndefinedBehaviorSanitizer. Kein Test bestätigt die reale Hydraulik oder Relaisfunktion.

Ausführen im Projekt: `python3 tests/host/test_off_heat_recovery.py`, `python3 tests/host/test_recovery_setting.py`, `python3 tests/host/test_space_heating_gate.py` und `python3 tests/host/test_network_recovery.py`.

## Laufzeitvergleich bei langsamem Webserver

Die erste vom Betreiber gemeldete Diagnose nach etwa drei Minuten Laufzeit enthielt 133260 Bytes freien Heap, 68600 Bytes Minimum und 110580 Bytes als größten Block. Das letzte Schleifenmaximum lag bei 12,674 ms, das bisherige Maximum bei 285,588 ms mit vier Abständen über 100 ms. Das sind Ausgangswerte, kein nachgewiesener Fehler.

Beim nächsten Langsamwerden Laufzeit und dieselben Diagnosewerte vergleichen. Zuvor war die Seite nach knapp sechs Tagen langsam, MQTT kam weiterhin an und die Geräte-Laufzeit lief weiter. Eine konkrete Ursache ist bislang nicht nachgewiesen; die Diagnose stellt noch keine Behebung dar.

## Letzte Optimierungen: Prüfumfang und offene Gerätetests

Erfolgreich durchgeführt wurden der Firmware-Build, Prüfungen der echten MQTT-Modusfunktionen bei erfolgreichem/fehlgeschlagenem Speichern und Wiederholungen, Vergleich der kompletten HTML-Ausgabe bei Puffergrößen von 1 bis 1460 Bytes, Prozentzeichen-/Leerwertfälle, OTA-Callback-/Fehlerfälle sowie JavaScript-Syntaxprüfungen.

Ein lokaler Test der ArduinoJson-Speicherwiederverwendung über 10000 Zyklen zeigte nach der Aufwärmphase stabilen belegten Speicher und weniger Allokationen. Das war ein lokaler Bibliothekstest, keine 10000-Zyklen-Messung am ESP32.

Nach Upload der neuesten Optimierungen noch prüfen:

1. Hauptseite vollständig auf Desktop und Mobilgerät laden; Uhrzeit, Trends und Werte müssen weiter aktualisiert werden.
2. Betriebsarten über Web und MQTT umschalten; Urlaub separat gemäß [Urlaubsbetrieb](https://github.com/cperners/heizung/wiki/Urlaubsbetrieb) prüfen.
3. Neue Heap-Ausgangswerte nach dem Start notieren und beim nächsten Langsamwerden vergleichen.
4. Bei einem späteren OTA-Fehler die Zeile OTA oder `/ota-status` prüfen; Diagnose wird bei Neustart zurückgesetzt.

Die letzte bestätigte Auswahlreihenfolge lautet Aus, Automatikbetrieb, nur Heizung, nur Boiler, Urlaub. Der Gerätetest der neuesten Speicher-/OTA-Optimierungen und ein dokumentierter mehrtägiger Vergleich stehen noch aus.

## Neue Web-Einstellungen und Mischer-Schließfahrt

Lokal erfolgreich geprüft: Firmware-Build, JavaScript-Syntax, vollständige HTML-Platzhalterausgabe, Übernahme beider Wertepaare bei erfolgreichem Speichern, Beibehalten der bisherigen Werte und Puffer bei Speicherfehler, Grenzwerte und nicht endliche Eingaben, Statusfarben und Zuordnung der fünf Ausgänge. Ein Host-Ablauftest prüft die Boiler-Schließfahrt vor/bei Ablauf von 120 Sekunden, dauerhaftes Stoppen, erneuten Eintritt, Betriebsartwechsel, Vorrang der Sensorsperre und Übergang nach Aus. Dies ersetzt keinen Gerätetest.

Nach dem Upload noch gezielt prüfen:

1. Alle fünf Temperatur-Kacheln: Bezeichnung, Temperatur und dann Ausgangssymbole; keine separate Ausgangsstatus-Kachel.
2. Boiler-Sollwert und Einschaltdifferenz gemeinsam speichern und nach einem Neustart vergleichen.
3. Vorlaufmaximum und Kurvensteilheit gemeinsam speichern und nach Neustart vergleichen.
4. Kessel-minus-Boiler-Anzeige mit Vorzeichen und Pastellfarben prüfen; Messwerte bei Sensorfehler nicht als gültige Differenz darstellen.
5. Nur Boiler wählen: einmalige Schließfahrt, nach zwei Minuten beide Ausgänge aus; Betriebsartwechsel muss abbrechen.

Die neuen Funktionen sind noch nicht vollständig am Gerät bestätigt. Die Nachprüfung ist lokal getestet: 120 Sekunden erste Fahrt, 600 Sekunden Wartezeit ab Fahrtende, keine Nachfahrt bei sinkender Temperatur, genau eine weitere 120-Sekunden-Fahrt bei gleichem oder höherem Vorlauf, keine weitere Wiederholung, Abbruch bei Betriebsartwechsel und keine Nachfahrt bei ungültigem Messwert oder verworfener Referenz. Die lokale Prüfung deckt auch das Verhindern einer erneuten Fahrt nach Timerüberlauf bei bereits abgeschlossenem Ablauf ab.

Am Gerät zusätzlich prüfen: Referenztemperatur beim ersten Fahrtende notieren, nach zehn Minuten mit dem Vorlauf vergleichen und die gegebenenfalls folgende zweite Schließfahrt beobachten. Dieser Ablauf ist noch nicht am Gerät bestätigt.

## Unbeabsichtigter Wechsel nach ioBroker-Neustart

Beim manuellen Neustart von ioBroker wurde auf dem Heizungs-Steuerthema `setheizung` beobachtet. Nach Deaktivieren von **Eigene States beim Verbinden publizieren** im MQTT-Client-Adapter blieb die Heizung bei wiederholtem Neustart in Aus und es kam kein neuer Steuerbefehl. Dies bestätigt die Start-Veröffentlichung für den beobachteten Fall. Die Option betrifft alle eigenen States der betreffenden Adapterinstanz; normale spätere Aktualisierungen bleiben möglich. Der nächste reguläre Proxmox-Backup-Lauf war noch zu beobachten.

Das ist von dem früheren IP-Ausfall nach dem Ausschalten zu trennen. Dessen Ursache ist nicht abschließend bewiesen. Die ergänzte WLAN-Korrektur und Wiederanlaufdiagnose liefern Gegenmaßnahmen und weitere Messwerte, aber keinen nachträglichen Absturzbeweis.

## Raumzielprüfung bei kaltem Kessel

Die lokalen Tests in `tests/host/test_space_heating_gate.py` decken zusätzlich ab: laufende Pumpe bei weiterem Wärmebedarf bleibt angefordert, stehende Pumpe startet ohne Kesselfreigabe nicht, Erreichen beziehungsweise Überschreiten des Tag-/Nacht-Sollwerts beendet die Anforderung, im Hystereseband bleibt der bisherige Zustand erhalten, und ungültige/nicht endliche Messwerte lösen keine falsche Raumzielentscheidung aus. Build und lokale Prüfungen waren erfolgreich.

Der Betreiber meldete nach dem Einspielen einen zunächst passenden Eindruck. Ein vollständig dokumentierter Gerätetest aller Grenzfälle steht noch aus. Am Gerät sind insbesondere Abschalten am Raum-Sollwert und Wiederanlauf bei erneuter Wärmeanforderung mit Kesselfreigabe zu prüfen.

## Kombinierte Raumregelung, Mischerimpulse und Boilerprüfung

Aktuell lokal geprüft sind:

- Raumwärmebedarf mit erlaubtem/gesperrtem Pumpenneustart, Weiterbetrieb bei kaltem Kessel, Tag-/Nacht-Sollwert, Hystereseband, Pumpenstopp und normale Mischerabschaltung am Raum-Sollwert.
- Vorlaufregelung bei Raumwärmebedarf mit gültigem Außenfühler, notwendige Sensorzuordnung und Unterdrückung normaler Anforderungen bei ungültiger Kurve.
- Normale Mischerfrist vor/bei fünf Sekunden ohne LCD-Ticks, beide Ruhezonengrenzen und exakter Sollwert, frühes Stoppen bei Sollwerteintritt/Richtungswechsel sowie 32-Bit-Zeitüberlauf.
- Getrennte Initialisierungs-, Aus-, Nur-Boiler- und Sensorfehlerfahrten: Der normale Impulsdienst verkürzt ihre längere Fahrzeit nicht.
- Boilerpumpenanforderung bei negativem beziehungsweise gleichem Kessel-Boiler-Temperaturverhältnis, auch ohne erneuten Aufruf der Ladeprüfung; der vereinbarte Fehlernachlauf bleibt erhalten.
- Berechnete Vorlaufanzeige und Differenzvorzeichen sowie Hinweise bei inaktivem/ungültigem Zustand; Web-JavaScript und vollständige Platzhalterliste.

Die lokalen Prüffälle verwenden tatsächliche Quellfunktionen mit simulierten Sensoren, Zeit und Ausgängen. Sie beweisen keine optimale Abstimmung des Mischermotors auf die reale Hydraulik. Die fünf Sekunden Fahrzeit und der 30-Sekunden-Abstand bleiben vorhandene Parameter; ihre optimale Einstellung erfordert reale Stellzeit und Temperaturverläufe.

Zusätzlich zu den bisherigen Hosttests: `python3 tests/host/test_mixer_pulses.py` und `python3 tests/host/test_vorlauf_display.py`.

Nach Upload noch am Gerät prüfen: Pumpenstart mit Kesselfreigabe bei Raumwärmebedarf, Vorlaufnachführung, Ruhe am Sollwert, Pumpen- und Mischerstopp bei erreichtem Raum-Sollwert, Verhalten beim Wechsel der Regelungsart und Ende der normalen Boilerladung bei nicht positivem Temperaturunterschied. Die neuesten kombinierten Funktionen sind noch nicht vollständig am Gerät bestätigt.

## Anmeldung, WLAN, MQTT und offener Update-Zugang

Am Gerät vom Betreiber bestätigt:

- Änderung des Web-Anmeldepassworts und anschließende Anmeldung.
- Zugriff auf die ausdrücklich wieder ungesperrte Update-Seite.

Lokal geprüft sind außerdem Zugriff ohne/mit Sitzung, Abmeldung und Ablauf nach 15
Minuten, Timerüberlauf, Passwort-Speicherfehler, alte achtstellige Datensätze,
Anmeldung und Speicherung bei 64 Bytes sowie Ablehnung bei 65 Bytes. Die Eingabesperre
und die freien Umschalter wurden mit einer DOM-Simulation geprüft. Diese Prüfung ist
kein vollständiger realer Browsertest.

Die WLAN-/MQTT-Tests verwenden die tatsächlichen Quellfunktionen mit simulierten
HTTP-, Treiber- und NVS-Schnittstellen. Sie decken den stabilen WLAN-Verbindungstest,
Rückfall, Neustart mit alten gespeicherten Daten, optionale Broker-Anmeldung, bewusste
anonyme Verbindung, Passwortbeibehaltung, ungültige Eingaben, Datensatzmigration und
Rückfall aller MQTT-Werte bei fehlender Verbindung oder Speicherfehler ab. Alte
Steuerthemen werden nach Wechsel nicht mehr angenommen.

Ausführung im Projektordner:

```sh
python3 tests/host/test_web_access.py
node tests/host/test_web_access_ui.js
```

Noch am Gerät zu dokumentieren: lange Passwörter einschließlich Neustart,
WLAN-Wechsel mit neuer IP und bewusst falschen Daten, MQTT-Wechsel mit/ohne gültige
Broker-Anmeldung, Bestätigung der neuen Themen und erneuter Kachelofen-Empfang.
Die Heizungsprüfungen der vorherigen Version bleiben weiterhin relevant.
Die frühere Ablehnung des geänderten Passworts an der OTA-Anmeldung bleibt als Ursache
offen; der aktuelle Stand nimmt den Update-Zugang bewusst vom Schutz aus.
